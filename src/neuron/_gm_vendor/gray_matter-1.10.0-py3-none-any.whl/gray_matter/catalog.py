"""Catalogo degli ambienti e dei loro comandi — la sorgente che alimenta la GUI.

SSOT: qui NON c'è nessun elenco di comandi. Ogni tool dichiara i propri e questo
modulo li **legge**:

  * Gray Matter e NeuRAG espongono ``build_parser()`` (argparse) → i subcomandi
    e i loro argomenti si ricavano per introspezione;
  * Neuron espone ``COMMANDS`` (dict) perché il suo dispatch non è argparse.

Conseguenza voluta: un subcomando aggiunto a una CLI compare nel control center
da solo, senza toccare la GUI. Un tool non installato semplicemente non compare.

SoC: questo modulo *descrive* soltanto. Non esegue nulla — l'esecuzione è di
``webgui`` (un solo runner generico), il rendering della pagina è dell'HTML.
"""
from __future__ import annotations

import importlib
import importlib.util   # esplicito: `import importlib` NON garantisce .util

# Ordine di rendering: dal più grande al più piccolo.
GROUPS = (
    ("lifecycle",   "Ciclo di vita"),
    ("maintenance", "Manutenzione"),
    ("inspect",     "Ispezione"),
    ("tuning",      "Regolazione"),
    ("other",       "Altro"),
)
_DEFAULT_GROUP = "other"   # un comando nuovo è VISIBILE anche prima di avere un gruppo

# Comandi che nella GUI non hanno senso (aprirebbero un'altra GUI).
GUI_HIDDEN = {("gray-matter", "gui"), ("neuron", "gui"), ("neurag", "gui"),
              ("gray-matter", "record-env"),
              ("neuron", "record-paths"), ("neurag", "record-paths")}

# Comandi interattivi: fanno domande all'utente. La GUI li avverte e collega
# lo stdin del processo alla riga di risposta sotto la console. Prima li
# dirottava in una finestra `cmd` esterna — la finestra nera che spuntava
# dalla GUI; ora la console del pannello è a tutti gli effetti un terminale.
INTERACTIVE = {("gray-matter", "cloud"),
               ("neuron", "setup"), ("neuron", "manage"), ("neuron", "connect")}

# Spiegazioni per persone, non per CLI: la GUI mostra queste; il testo argparse
# resta il fallback per i comandi nuovi non ancora descritti qui.
#
# Ogni voce dice DUE cose, perché sapere cosa fa un comando non basta a sapere
# se è quello giusto adesso:
#     (cosa_it, quando_it, what_en, when_en)
# "cosa" = che effetto ha · "quando" = in quale situazione serve davvero.
# Le due lingue stanno QUI e non in due dizionari separati: tenerle accostate
# è l'unico modo perché una traduzione mancante si veda subito (vedi il
# self-check in demo(), che le conta).
DOCS: "dict[tuple[str, str], tuple[str, str, str, str]]" = {

    # ── Gray Matter — ciclo di vita ──────────────────────────────────────
    ("gray-matter", "install"): (
        "Installa/ripara il gateway: registra Gray Matter nei client AI e collega Neuron e NeuRAG.",
        "La prima volta, e ogni volta che un client AI non vede più i tool. È idempotente: rilanciarlo non rompe nulla.",
        "Install/repair the gateway: registers Gray Matter in your AI clients and wires up Neuron and NeuRAG.",
        "The first time, and any time an AI client stops seeing the tools. It is idempotent — re-running it breaks nothing.",
    ),
    ("gray-matter", "uninstall"): (
        "Rimuove Gray Matter dai client AI. Chiede cosa fare della memoria.",
        "Quando vuoi smettere di usare la suite. La memoria si conserva se non dici esplicitamente di cancellarla.",
        "Removes Gray Matter from your AI clients. Asks what to do with your memory.",
        "When you want to stop using the suite. Your memory is kept unless you explicitly ask to delete it.",
    ),
    ("gray-matter", "repair"): (
        "Pulizia selettiva: scegli cosa cancellare (memoria, conoscenza, ponti, config, registrazioni) e cosa tenere. Da solo NON reinstalla: con --reinstall rilancia subito l'installer con -Force (bypass del check di versione), che riscrive registro, hook ed entry nei client.",
        "Quando 'install' non basta più: codice aggiornato ma stessa versione, o uno stato che non torna. Prima prova 'doctor'.",
        "Selective cleanup: pick what to delete (memory, knowledge, bridges, config, registrations) and what to keep. Alone it does NOT reinstall: --reinstall runs the installer right away with -Force (bypassing the version check), which rewrites the registry, the hook and the client entries.",
        "When 'install' is no longer enough: code changed but the version did not, or state that no longer adds up. Try 'doctor' first.",
    ),
    ("gray-matter", "start"): (
        "Avvia il daemon Gray Matter in background.",
        "Raramente a mano: il client AI lo avvia da solo. Serve per test, o dopo uno 'stop'.",
        "Starts the Gray Matter daemon in the background.",
        "Rarely by hand — your AI client starts it for you. Useful for testing, or after a 'stop'.",
    ),
    ("gray-matter", "stop"): (
        "Ferma il daemon Gray Matter.",
        "Prima di un aggiornamento, o per liberare la porta se sospetti due daemon in esecuzione.",
        "Stops the Gray Matter daemon.",
        "Before an update, or to free the port if you suspect two daemons are running.",
    ),
    ("gray-matter", "register"): (
        "Registra il GATEWAY nei client AI (Claude, Cursor, ecc.). Neuron e NeuRAG restano gestiti dal proxy.",
        "Dopo aver installato un nuovo client AI, o per tornare al modello gateway dopo un 'go-standalone'.",
        "Registers the GATEWAY in your AI clients (Claude, Cursor, ...). Neuron and NeuRAG stay behind the proxy.",
        "After installing a new AI client, or to return to the gateway model after a 'go-standalone'.",
    ),
    ("gray-matter", "deregister"): (
        "Fa uscire un tool (o entrambi) dal gateway: lo toglie dalla gestione GM e lo registra come MCP diretto nei client.",
        "Quando vuoi usare Neuron o NeuRAG da solo, senza il gateway. Reversibile con 'link'.",
        "Takes a tool (or both) off the gateway: GM stops managing it and it registers directly in your clients.",
        "When you want to use Neuron or NeuRAG on its own, without the gateway. Undo it with 'link'.",
    ),
    ("gray-matter", "link"): (
        "Ri-aggancia al gateway i tool andati standalone: GM riprende a gestirli e la loro entry MCP diretta sparisce dai client.",
        "L'inverso di 'deregister', quando vuoi tornare a un solo connettore.",
        "Re-attaches standalone tools to the gateway: GM manages them again and their direct MCP entry disappears from your clients.",
        "The inverse of 'deregister', when you want a single connector again.",
    ),

    # ── Gray Matter — ispezione ──────────────────────────────────────────
    ("gray-matter", "status"): (
        "Stato del daemon e dei server registrati (Neuron, NeuRAG), con i loro tool.",
        "Prima domanda da farsi quando l'AI 'non ricorda': se qui i server non compaiono, il resto non può funzionare.",
        "Daemon status and the registered servers (Neuron, NeuRAG), with their tools.",
        "The first thing to check when your AI 'forgets': if the servers are missing here, nothing else can work.",
    ),
    ("gray-matter", "doctor"): (
        "Controllo di salute completo: cablaggio (registro, hook, entry MCP, versioni, processi stantii), server, worker, cache, ponti, tier di storage.",
        "Quando qualcosa non va e non sai da dove partire. È il comando diagnostico da lanciare per primo.",
        "Full health check: wiring (registry, hook, MCP entries, versions, stale processes), servers, workers, cache, bridges, storage tier.",
        "When something is wrong and you do not know where to start. This is the first diagnostic to run.",
    ),
    ("gray-matter", "ping"): (
        "Verifica veloce: il daemon risponde?",
        "Un sì/no immediato, più rapido di 'status', utile negli script.",
        "Quick check: is the daemon answering?",
        "An immediate yes/no, faster than 'status', handy in scripts.",
    ),
    ("gray-matter", "stats"): (
        "Contatori di sessione: cache hit, flash, ponti, latenza media.",
        "Per capire se la cache sta lavorando e quanto costa davvero un pulse.",
        "Session counters: cache hits, flashes, bridges, average latency.",
        "To see whether the cache is doing its job and what a pulse really costs.",
    ),
    ("gray-matter", "logs"): (
        "Mostra il log del daemon (le ultime righe).",
        "Dopo un crash o un avvio fallito: è lì che finiscono i traceback del daemon.",
        "Shows the daemon log (the last lines).",
        "After a crash or a failed start — daemon tracebacks land there.",
    ),
    ("gray-matter", "bridges"): (
        "Elenca i ponti salvati fra memoria (Neuron) e conoscenza (NeuRAG), con il loro peso.",
        "Per vedere cosa la suite ha imparato a collegare da sola con l'uso.",
        "Lists the saved bridges between memory (Neuron) and knowledge (NeuRAG), with their weight.",
        "To see what the suite has learned to connect on its own, through use.",
    ),
    ("gray-matter", "gm-neuron"): (
        "Chiama un tool di Neuron passando dal gateway.",
        "Per test e diagnosi: verifica che il percorso client → gateway → worker funzioni davvero.",
        "Calls a Neuron tool through the gateway.",
        "For testing and diagnosis: proves the client → gateway → worker path actually works.",
    ),
    ("gray-matter", "gm-neurag"): (
        "Chiama un tool di NeuRAG passando dal gateway.",
        "Come gm-neuron, ma per la base di conoscenza.",
        "Calls a NeuRAG tool through the gateway.",
        "Like gm-neuron, but for the knowledge base.",
    ),

    # ── Gray Matter — regolazione e rete ─────────────────────────────────
    ("gray-matter", "config"): (
        "Configurazione del gateway: cache (TTL, dimensione), stimoli (flash rate), tetti di token per memoria e conoscenza, prewarm, tool sganciati.",
        "Per regolare il comportamento senza toccare il codice. Parti da action=list per vedere cosa esiste.",
        "Gateway configuration: cache (TTL, size), stimuli (flash rate), token caps for memory and knowledge, prewarm, unmanaged tools.",
        "To tune behaviour without touching code. Start with action=list to see what exists.",
    ),
    ("gray-matter", "cloud"): (
        "Collega i database al cloud Turso (chiede URL e token).",
        "Quando vuoi la stessa memoria su più computer. In locale non serve: il file .db basta.",
        "Connects the databases to Turso cloud (asks for URL and token).",
        "When you want the same memory on more than one computer. Not needed locally — the .db file is enough.",
    ),
    ("gray-matter", "mode"): (
        "Tutti i server insieme (collaborate) o ognuno per sé (separate).",
        "'separate' isola i due store quando vuoi capire quale dei due risponde male.",
        "All servers together (collaborate) or each on its own (separate).",
        "'separate' isolates the two stores when you want to work out which one is answering badly.",
    ),
    ("gray-matter", "isolate"): (
        "Escludi un server (neuron|neurag) dal pulse combinato.",
        "Per provare la suite senza uno dei due, o mentre ne ripari uno.",
        "Excludes a server (neuron|neurag) from the combined pulse.",
        "To try the suite without one of them, or while you are repairing one.",
    ),
    ("gray-matter", "collaborate"): (
        "Rimetti un server (neuron|neurag) nel pulse combinato.",
        "L'inverso di 'isolate', quando hai finito.",
        "Puts a server (neuron|neurag) back into the combined pulse.",
        "The inverse of 'isolate', when you are done.",
    ),
    ("gray-matter", "bridge"): (
        "Espone l'intera suite (Neuron + NeuRAG + GM) su HTTP per connettori remoti.",
        "Per usare la memoria da client che non parlano stdio MCP (Perplexity, ChatGPT). Resta in esecuzione.",
        "Exposes the whole suite (Neuron + NeuRAG + GM) over HTTP for remote connectors.",
        "To use your memory from clients that do not speak stdio MCP (Perplexity, ChatGPT). Keeps running.",
    ),
    ("gray-matter", "bridges-transfer"): (
        "Sposta i ponti fra locale e cloud. È additivo: non cancella nulla.",
        "Quando passi al cloud e vuoi portarti dietro quello che la suite ha già imparato.",
        "Moves bridges between local and cloud. Additive — it never deletes anything.",
        "When you move to the cloud and want to bring along what the suite already learned.",
    ),
    ("gray-matter", "reap"): (
        "Termina i processi della suite rimasti indietro: quelli il cui genitore (il client AI) non esiste più.",
        "Quando 'doctor' segnala degli orfani. Non tocca i server che stanno servendo un client vivo — quelli servono.",
        "Terminates suite processes left behind: the ones whose parent (the AI client) is gone.",
        "When 'doctor' reports orphans. It leaves alone the servers still serving a live client — those are in use.",
    ),
    ("gray-matter", "knowledge"): (
        "Manutenzione della base di conoscenza NeuRAG (status, rebuild-links, link-graph).",
        "Scorciatoia per i comandi NeuRAG più usati, senza cambiare ambiente.",
        "NeuRAG knowledge base maintenance (status, rebuild-links, link-graph).",
        "A shortcut to the most-used NeuRAG commands without switching environment.",
    ),

    # ── Neuron ───────────────────────────────────────────────────────────
    ("neuron", "setup"): (
        "Installa, aggiorna o ripara Neuron. Fa domande.",
        "Per gestire Neuron da solo. Con la suite installata, 'gray-matter install' copre già tutto.",
        "Installs, updates or repairs Neuron. It asks questions.",
        "To manage Neuron on its own. With the suite installed, 'gray-matter install' already covers this.",
    ),
    ("neuron", "manage"): (
        "Gestione quotidiana del grafo di memoria. Fa domande.",
        "Per operazioni di manutenzione guidate sul grafo, una alla volta.",
        "Day-to-day management of the memory graph. It asks questions.",
        "For guided maintenance on the graph, one operation at a time.",
    ),
    ("neuron", "connect"): (
        "Collega un DB Turso Cloud a Neuron (chiede URL e token).",
        "Solo per la memoria di Neuron. Per tutta la suite usa 'gray-matter cloud'.",
        "Connects a Turso Cloud DB to Neuron (asks for URL and token).",
        "For Neuron's memory only. For the whole suite use 'gray-matter cloud'.",
    ),
    ("neuron", "register"): (
        "Registra Neuron come MCP DIRETTO nei client (standalone, senza gateway).",
        "Solo se non usi Gray Matter: con il gateway attivo crea una doppia registrazione.",
        "Registers Neuron as a DIRECT MCP server in your clients (standalone, no gateway).",
        "Only if you are not using Gray Matter: with the gateway active this creates a double registration.",
    ),
    ("neuron", "doctor"): (
        "Diagnostica e ripara le registrazioni di Neuron nei client AI.",
        "Quando un client vede Neuron e un altro no: confronta i config e li rimette a posto.",
        "Diagnoses and repairs Neuron's registrations in your AI clients.",
        "When one client sees Neuron and another does not: it compares the configs and fixes them.",
    ),
    ("neuron", "console"): (
        "Fotografia del grafo di memoria, in sola lettura.",
        "Per guardare cosa Neuron ha imparato senza rischiare di modificarlo.",
        "A read-only snapshot of the memory graph.",
        "To look at what Neuron has learned with no risk of changing it.",
    ),
    ("neuron", "consolidate"): (
        "Pulizia della memoria: fonde i quasi-duplicati e archivia gli orfani.",
        "Ogni tanto, quando il grafo si è riempito di varianti dello stesso concetto ('spring boot' / 'Spring Boot').",
        "Memory cleanup: merges near-duplicates and archives orphans.",
        "Every so often, when the graph has filled up with variants of the same concept ('spring boot' / 'Spring Boot').",
    ),
    ("neuron", "start"): (
        "Avvia il server Neuron in background (bridge HTTP per connettori remoti).",
        "Solo per i connettori remoti: il client AI non ha bisogno di questo.",
        "Starts the Neuron server in the background (HTTP bridge for remote connectors).",
        "For remote connectors only — your AI client does not need this.",
    ),
    ("neuron", "stop"): (
        "Ferma il server Neuron avviato con 'start'.",
        "Quando hai finito con i connettori remoti.",
        "Stops the Neuron server started with 'start'.",
        "When you are done with the remote connectors.",
    ),
    ("neuron", "bridge"): (
        "Espone Neuron su HTTP per i connettori remoti. Resta in esecuzione.",
        "Come 'gray-matter bridge', ma per la sola memoria.",
        "Exposes Neuron over HTTP for remote connectors. Keeps running.",
        "Like 'gray-matter bridge', but for memory alone.",
    ),
    ("neuron", "tunnel"): (
        "HTTPS pubblico via cloudflared, da usare insieme al bridge. Resta in esecuzione.",
        "Quando il connettore remoto è su internet e non può raggiungere il tuo localhost.",
        "Public HTTPS via cloudflared, to be used together with the bridge. Keeps running.",
        "When the remote connector lives on the internet and cannot reach your localhost.",
    ),
    ("neuron", "init"): (
        "Cablaggio dei client AI senza avviare il server.",
        "Quando vuoi solo scrivere la configurazione, senza caricare il modello.",
        "Wires up your AI clients without starting the server.",
        "When you only want to write the configuration, without loading the model.",
    ),
    ("neuron", "go-standalone"): (
        "Neuron esce dal gateway e si registra come MCP diretto nei client.",
        "Per usare solo la memoria, senza knowledge base. Reversibile con 'gray-matter link'.",
        "Neuron leaves the gateway and registers as a direct MCP server in your clients.",
        "To use memory alone, without the knowledge base. Undo with 'gray-matter link'.",
    ),
    ("neuron", "repair"): (
        "Pulizia selettiva SOLO di Neuron: scegli cosa cancellare (memoria, config). Con --reinstall rilancia subito l'installer di Neuron con -Force.",
        "Quando è Neuron a essere rotto e non vuoi toccare NeuRAG né il gateway.",
        "Selective cleanup of Neuron ONLY: pick what to delete (memory, config). --reinstall then runs Neuron's installer right away with -Force.",
        "When Neuron is the broken one and you do not want to touch NeuRAG or the gateway.",
    ),
    ("neuron", "migrate"): (
        "Migra i grafi dalla vecchia slug (neuron5) alla nuova (neuron). Idempotente.",
        "Una volta sola, arrivando da un'installazione vecchia. Se non hai grafi vecchi non fa nulla.",
        "Migrates graphs from the old slug (neuron5) to the new one (neuron). Idempotent.",
        "Once only, coming from an old installation. With no old graphs it does nothing.",
    ),
    # Neuron non ha un comando `uninstall` a sé: la disinstallazione passa da
    # `neuron setup --uninstall` (è così che la invoca anche la card della GUI,
    # vedi webgui._detect_uninstall_tools). Documentarlo qui significava
    # descrivere un comando inesistente — lo `demo()` ora lo impedisce.

    # ── NeuRAG ───────────────────────────────────────────────────────────
    ("neurag", "status"): (
        "Stato della base di conoscenza: nodi, chunk, collegamenti, motore di storage.",
        "Per sapere se il vault è popolato e su quale tier gira (Turso o sqlite3).",
        "Knowledge base status: nodes, chunks, links, storage engine.",
        "To see whether the vault has content and which tier it runs on (Turso or sqlite3).",
    ),
    ("neurag", "query"): (
        "Cerca nella base di conoscenza. Scrivi la domanda nel campo query.",
        "Per provare cosa troverebbe l'AI prima di fidarti del vault.",
        "Searches the knowledge base. Type your question in the query field.",
        "To see what your AI would find, before you trust the vault.",
    ),
    ("gray-matter", "backup"): (
        "Copia i tre store — grafi Neuron, vault NeuRAG, bridge GM — in una "
        "cartella per giorno, gm-graph-backup_<data>, con una sottocartella per "
        "tool. Tiene gli ultimi 7 giorni. Il daemon lo fa da solo una volta al "
        "giorno; --force rifà la copia di oggi.",
        "Prima di un'operazione che non torna indietro (consolidate, reindex, "
        "un --apply) o a fine giornata: la copia automatica è di inizio giornata, "
        "il lavoro fatto dopo non c'è ancora. Non serve il daemon acceso.",
        "Copies the three stores — Neuron graphs, NeuRAG vault, GM bridges — into "
        "one folder per day, gm-graph-backup_<date>, one subfolder per tool. "
        "Keeps the last 7 days. The daemon does it once a day on its own; "
        "--force redoes today's copy.",
        "Before anything that does not undo (consolidate, reindex, an --apply) "
        "or at the end of the day: the automatic copy is from the start of the "
        "day, later work is not in it yet. The daemon need not be running.",
    ),
    ("gray-matter", "promote"): (
        "Promuove in conoscenza permanente (NeuRAG) i concetti stabili della "
        "memoria (Neuron): vecchi abbastanza e confermati, o ancorati da link "
        "forti. Ogni concetto arriva con le ragioni dei suoi link e i suoi "
        "episodi come chunk, sotto il godnode 'memoria promossa'. NON scrive niente senza --apply.",
        "Su una memoria vissuta: un concetto ripetuto per centinaia di turni "
        "resta nello store che decade e non diventa mai conoscenza. Lancialo "
        "prima senza --apply e leggi la lista — un nodo promosso non decade, "
        "quindi promuovere rumore è più costoso che non promuovere niente.",
        "Promotes stable memory concepts (Neuron) into permanent knowledge "
        "(NeuRAG): old enough and confirmed, or anchored by strong links. Each "
        "one lands with its link rationales and episodes as chunks, under the "
        "'memoria promossa' godnode. Writes NOTHING unless you pass --apply.",
        "On a memory with history: a concept repeated across hundreds of turns "
        "stays in the decaying store and never becomes knowledge. Run it without "
        "--apply first and read the list — a promoted node does not decay, so "
        "promoting noise costs more than promoting nothing.",
    ),
    ("neurag", "confirm"): (
        "Segnala che due o più nodi sono stati utili INSIEME: i collegamenti fra "
        "loro si rinforzano e sopravvivono al prossimo ingest.",
        "Dopo una risposta che ha funzionato davvero. È la conferma a insegnare, "
        "non il fatto che siano usciti insieme in una ricerca: il recupero è "
        "poco costoso e spesso sbaglia, quindi rinforzarlo insegnerebbe al "
        "grafo quello che il ranking già crede.",
        "Marks two or more nodes as having been useful TOGETHER: the links "
        "between them are reinforced and outlive the next ingest.",
        "After an answer that actually worked. Confirmation is what teaches, not "
        "the fact that they came back together in one search: retrieval is cheap "
        "and often wrong, so reinforcing it would teach the graph whatever the "
        "ranking already believed.",
    ),
    ("neurag", "related"): (
        "Cosa si collega a un nodo, per attivazione che si propaga lungo i link. "
        "Ordinato per forza del legame, non per numero di salti.",
        "Quando la ricerca per testo non basta: trova quello che è associato ma "
        "non contiene le parole della domanda. Solo grafo, nessun embedding.",
        "What a node connects to, by activation spreading along the links. "
        "Ranked by how strongly, not by hop count.",
        "When a text search is not enough: it finds what is associated but does "
        "not contain the words you asked about. Graph only, no embedding.",
    ),
    ("neurag", "recall"): (
        "Cerca in TUTTI i layer, anche nei nodi parcheggiati (dormienti). "
        "Niente viene mai cancellato: viene solo messo da parte.",
        "Quando sai che una cosa c'era e 'query' non la trova più: probabilmente "
        "è stata parcheggiata perché nessuno la consultava da mesi.",
        "Searches EVERY layer, parked (dormant) nodes included. Nothing is ever "
        "deleted here — only set aside.",
        "When you know something was there and 'query' no longer finds it: it has "
        "most likely been parked after months without being consulted.",
    ),
    ("neurag", "park"): (
        "Elenca i nodi rimasti inattivi abbastanza a lungo da scendere a un layer "
        "dormiente. NON tocca niente finché non passi --apply.",
        "Su un vault grosso e vecchio, per togliere dalla scansione di default "
        "quello che non risponde più a nessuno. Un nodo parcheggiato resta "
        "raggiungibile con 'recall': lancialo prima senza --apply e leggi la lista.",
        "Lists nodes idle long enough to drop to a dormant layer. Changes NOTHING "
        "unless you pass --apply.",
        "On a large, old vault, to take what no longer answers anything out of the "
        "default scan. A parked node stays reachable through 'recall' — run it "
        "without --apply first and read the list.",
    ),
    ("neurag", "unpark"): (
        "Riporta un nodo dormiente nel vault attivo.",
        "Quando 'park' ha messo da parte qualcosa che ti serve ancora: torna nella "
        "ricerca normale, senza dover usare 'recall' ogni volta.",
        "Brings a dormant node back into the active vault.",
        "When 'park' set aside something you still need: it returns to ordinary "
        "search instead of needing 'recall' every time.",
    ),
    ("neurag", "decay"): (
        "Indebolisce il peso dei collegamenti e la salienza dei tag in base al "
        "tempo passato dall'ultima esecuzione. Non cancella nulla: le rotte "
        "sbiadiscono, non spariscono.",
        "Manutenzione periodica su un vault vivo: quello che usi si rinforza da "
        "solo a ogni ricerca, quello che non usi arretra. Lanciarlo due volte di "
        "fila non raddoppia l'effetto.",
        "Weakens link weights and tag salience by the time elapsed since the last "
        "run. Deletes nothing: routes get fainter, they never disappear.",
        "Periodic upkeep on a live vault: what you use reinforces itself on every "
        "search, what you don't recedes. Running it twice in a row does not "
        "double the effect.",
    ),
    ("neurag", "tree"): (
        "Mostra la gerarchia dei nodi di conoscenza.",
        "Per orientarti nel vault e capire dove finirà un nuovo documento.",
        "Shows the hierarchy of knowledge nodes.",
        "To get your bearings in the vault and see where a new document will land.",
    ),
    ("neurag", "health"): (
        "Controllo di integrità strutturale del vault: orfani, gerarchia rotta, chunk vuoti.",
        "Dopo un ingest grosso, o quando le risposte peggiorano senza motivo apparente.",
        "Structural integrity check of the vault: orphans, broken hierarchy, empty chunks.",
        "After a large ingest, or when answers get worse for no obvious reason.",
    ),
    ("neurag", "doctor"): (
        "Fotografia dell'ambiente: tier di storage, embedder, stato del gateway.",
        "Quando la ricerca sembra debole: spesso l'embedder è degradato al fallback lessicale.",
        "Environment snapshot: storage tier, embedder, gateway status.",
        "When search feels weak — often the embedder has degraded to the lexical fallback.",
    ),
    ("neurag", "ingest"): (
        "Grafizza una cartella in automatico: nodi dalla struttura, chunk, embedding e link. Dai solo il percorso.",
        "Il modo normale di riempire il vault. Preferiscilo ad add-node/add-chunks a mano.",
        "Graphs a folder automatically: nodes from its structure, chunks, embeddings and links. Just give it a path.",
        "The normal way to fill the vault. Prefer it over add-node/add-chunks by hand.",
    ),
    ("neurag", "reindex"): (
        "Ricalcola i vettori di TUTTI i chunk con il modello di embedding attivo. "
        "Testo, nodi e link non vengono toccati e i file sorgente non servono.",
        "Dopo aver cambiato embed_model: i vettori di due modelli non sono "
        "confrontabili, quindi finché non rifai l'indice la ricerca semantica "
        "restituisce rumore. Se invece hai cambiato la DIMENSIONE dei chunk, usa "
        "'ingest' (ri-spezzetta leggendo i file).",
        "Recomputes the vectors for EVERY chunk with the active embedding model. "
        "Text, nodes and links are untouched, and the source files are not needed.",
        "After changing embed_model: vectors from two models are not comparable, so "
        "semantic search returns noise until the vault is rebuilt. If you changed the "
        "chunk SIZE instead, use 'ingest' (it re-chunks from the files).",
    ),
    ("neurag", "chunk"): (
        "Prova di spezzettamento di un file o cartella. Non salva nulla.",
        "Prima di un ingest, per vedere come verrebbe tagliato un documento.",
        "Dry-run chunking of a file or folder. Saves nothing.",
        "Before an ingest, to see how a document would be split.",
    ),
    ("neurag", "add-node"): (
        "Aggiunge un nodo alla gerarchia di conoscenza.",
        "Per costruire la struttura a mano. Con 'ingest' i nodi nascono da soli.",
        "Adds a node to the knowledge hierarchy.",
        "To build the structure by hand. With 'ingest' the nodes appear on their own.",
    ),
    ("neurag", "add-chunks"): (
        "Aggancia chunk (JSON da file o stdin) a un nodo esistente.",
        "Per contenuto che non viene da un file su disco.",
        "Attaches chunks (JSON from a file or stdin) to an existing node.",
        "For content that does not come from a file on disk.",
    ),
    ("neurag", "import"): (
        "Importa una cartella intera secondo una mappa YAML.",
        "Quando vuoi decidere tu la gerarchia invece di lasciarla dedurre a 'ingest'.",
        "Imports a whole folder following a YAML mapping.",
        "When you want to decide the hierarchy yourself instead of letting 'ingest' infer it.",
    ),
    ("neurag", "rename-node"): (
        "Rinomina un nodo (i path dei figli si aggiornano da soli).",
        "Per correggere un nome senza dover reimportare il sottoalbero.",
        "Renames a node (children's paths update themselves).",
        "To fix a name without re-importing the subtree.",
    ),
    ("neurag", "remove-node"): (
        "Elimina un nodo e tutto il suo sottoalbero, chunk compresi.",
        "Distruttivo e senza annulla: controlla prima con 'tree'.",
        "Deletes a node and its whole subtree, chunks included.",
        "Destructive and cannot be undone: check with 'tree' first.",
    ),
    ("neurag", "archive"): (
        "Dichiara storia un nodo: esce dalla ricerca normale, resta raggiungibile, non si cancella.",
        "Per documenti vecchi che rispondono ancora al posto di quelli attuali. --restore lo riporta.",
        "Declares a node history: out of the default search, still reachable, never deleted.",
        "For old documents that keep answering instead of the current ones. --restore brings it back.",
    ),
    ("neuron", "config"): (
        "Configurazione Neuron: quanti concetti tiene ogni grafo prima di archiviarne.",
        "Alzalo se la memoria dimentica concetti che ti servono; vale dal prossimo avvio. Parti da action=list.",
        "Neuron configuration: how many concepts each graph keeps before archiving.",
        "Raise it if the memory forgets concepts you need; applies from the next start. Start with action=list.",
    ),
    ("neurag", "config"): (
        "Configurazione NeuRAG: modello di embedding e dimensione dei chunk.",
        "Cambiare il modello di embedding richiede un re-index del vault. Parti da action=list.",
        "NeuRAG configuration: embedding model and chunk size.",
        "Rerank improves precision and costs time: turn it on if answers are imprecise. Start with action=list.",
    ),
    ("neurag", "register"): (
        "Registra NeuRAG come MCP DIRETTO nei client (standalone, senza gateway).",
        "Solo se non usi Gray Matter: con il gateway attivo crea una doppia registrazione.",
        "Registers NeuRAG as a DIRECT MCP server in your clients (standalone, no gateway).",
        "Only if you are not using Gray Matter: with the gateway active this creates a double registration.",
    ),
    ("neurag", "deregister"): (
        "Rimuove NeuRAG dai config dei client AI.",
        "Per togliere la sola knowledge base, lasciando il resto dov'è.",
        "Removes NeuRAG from your AI clients' configs.",
        "To remove the knowledge base alone, leaving everything else in place.",
    ),
    ("neurag", "go-standalone"): (
        "NeuRAG esce dal gateway e si registra come MCP diretto nei client.",
        "Per usare solo la knowledge base, senza memoria. Reversibile con 'gray-matter link'.",
        "NeuRAG leaves the gateway and registers as a direct MCP server in your clients.",
        "To use the knowledge base alone, without memory. Undo with 'gray-matter link'.",
    ),
    ("neurag", "start"): (
        "Avvia il server NeuRAG in background (MCP stdio).",
        "Raramente a mano: con il gateway ci pensa Gray Matter.",
        "Starts the NeuRAG server in the background (MCP stdio).",
        "Rarely by hand — with the gateway, Gray Matter handles it.",
    ),
    ("neurag", "stop"): (
        "Ferma il server NeuRAG.",
        "Prima di un aggiornamento, o per liberare il database.",
        "Stops the NeuRAG server.",
        "Before an update, or to release the database.",
    ),
    ("neurag", "repair"): (
        "Pulizia selettiva SOLO di NeuRAG: scegli cosa cancellare (conoscenza, config). Con --reinstall rilancia subito l'installer di NeuRAG con -Force.",
        "Quando è NeuRAG a essere rotto e non vuoi toccare Neuron né il gateway.",
        "Selective cleanup of NeuRAG ONLY: pick what to delete (knowledge, config). --reinstall then runs NeuRAG's installer right away with -Force.",
        "When NeuRAG is the broken one and you do not want to touch Neuron or the gateway.",
    ),
    ("neurag", "uninstall"): (
        "Deregistra NeuRAG dai client AI e, se lo chiedi, cancella il database della conoscenza.",
        "Quando vuoi togliere solo NeuRAG. Il vault resta se non chiedi di cancellarlo.",
        "Deregisters NeuRAG from your AI clients and, if you ask, deletes the knowledge database.",
        "When you want to remove NeuRAG only. The vault stays unless you ask to delete it.",
    ),
}


def doc_for(key: "tuple[str, str]", lang: str = "it") -> "tuple[str, str]":
    """(cosa fa, quando serve) per un comando, nella lingua chiesta.

    ("", "") se il comando non è ancora documentato: chi chiama ricade sul
    testo argparse, così un subcomando nuovo compare comunque nella GUI.
    """
    entry = DOCS.get(key)
    if not entry:
        return "", ""
    what_it, when_it, what_en, when_en = entry
    return (what_en, when_en) if lang == "en" else (what_it, when_it)


# ── Control center sections ─────────────────────────────────────────────
# The GUI is organised by what you are doing, and inside each section by tool:
#   ops      = everyday use (start, look, search, add knowledge)
#   graph    = graph maintenance (clean, archive, migrate, back up)
#   tools    = tool maintenance (install, repair, diagnose, clients)
#   settings = settings and connections (knobs, modes, cloud, tunnel)
SECTIONS = (
    ("ops",      "Comandi operativi", "Everyday commands"),
    ("graph",    "Manutenzione grafo", "Graph maintenance"),
    ("tools",    "Manutenzione tool", "Tool maintenance"),
    ("settings", "Impostazioni", "Settings"),
)
# A command not listed here still shows up: its CLI group decides.
_SECTION_OF_GROUP = {"lifecycle": "tools", "maintenance": "graph",
                     "inspect": "ops", "tuning": "settings", "other": "ops"}
SECTION_OF: "dict[tuple[str, str], str]" = {
    ("gray-matter", "start"): "ops", ("gray-matter", "stop"): "ops",
    ("gray-matter", "bridge"): "settings", ("gray-matter", "doctor"): "tools",
    ("gray-matter", "logs"): "tools", ("gray-matter", "ping"): "tools",
    ("gray-matter", "bridges"): "graph", ("gray-matter", "promote"): "graph",
    ("gray-matter", "reap"): "tools",
    ("neuron", "start"): "ops", ("neuron", "stop"): "ops",
    ("neuron", "bridge"): "settings", ("neuron", "tunnel"): "settings",
    ("neuron", "doctor"): "tools",
    ("neurag", "start"): "ops", ("neurag", "stop"): "ops",
    ("neurag", "doctor"): "tools", ("neurag", "health"): "tools",
    ("neurag", "ingest"): "ops", ("neurag", "add-node"): "ops",
    ("neurag", "add-chunks"): "ops", ("neurag", "chunk"): "ops",
    ("neurag", "import"): "ops", ("neurag", "confirm"): "ops",
    ("neurag", "decay"): "graph", ("neurag", "park"): "graph",
    ("neurag", "unpark"): "graph",
}


def section_of(tool: str, command: str, group: str) -> str:
    return SECTION_OF.get((tool, command)) or _SECTION_OF_GROUP.get(group, "ops")


# Arguments the form never shows: machine output for the control center itself.
GUI_HIDDEN_ARGS = {"json"}

# What each argument means, for someone who does not write code: (it, en).
# Key: (tool, command, dest) for a specific argument, or the bare dest for one
# that means the same everywhere. The argparse help stays the fallback.
ARG_DOCS: "dict[object, tuple[str, str]]" = {
    "dry_run": ("Prova generale: mostra cosa farebbe, senza cambiare niente.",
                "Rehearsal: shows what it would do, changes nothing."),
    "yes": ("Risponde 'sì' a ogni domanda: nessuna conferma richiesta.",
            "Answers 'yes' to every question: no confirmation asked."),
    "apply": ("Esegue davvero. Senza questa casella mostra solo il resoconto.",
              "Actually does it. Without this box it only reports."),
    "top_n": ("Quanti risultati mostrare. Vuoto = 5.",
              "How many results to show. Empty = 5."),
    "deep": ("Cerca anche fra i nodi parcheggiati (dormienti, non usati da tempo).",
             "Also searches parked nodes (dormant, unused for a while)."),
    ("gray-matter", "bridge", "host"): (
        "Indirizzo di rete su cui ascoltare. Vuoto = solo questo computer (127.0.0.1).",
        "Network address to listen on. Empty = this computer only (127.0.0.1)."),
    ("gray-matter", "bridge", "bind"): (
        "Scorciatoia: 'local' = solo questo computer, 'all' = visibile da tutta la rete.",
        "Shortcut: 'local' = this computer only, 'all' = visible to the whole network."),
    ("gray-matter", "bridge", "port"): (
        "Numero di porta. Vuoto = 8002.", "Port number. Empty = 8002."),
    ("gray-matter", "bridge", "port_range"): (
        "Se la porta è occupata, quante successive provare. Vuoto = 10.",
        "If the port is busy, how many following ones to try. Empty = 10."),
    ("gray-matter", "bridge", "tunnel"): (
        "Apre anche un tunnel pubblico (HTTPS) verso il bridge.",
        "Also opens a public tunnel (HTTPS) to the bridge."),
    ("gray-matter", "bridge", "no_check"): (
        "Salta i controlli iniziali. Solo se sai perché falliscono.",
        "Skips the initial checks. Only if you know why they fail."),
    ("gray-matter", "deregister", "tool"): (
        "Quale tool togliere dal gateway: neuron, neurag o all (tutti). Vuoto = all.",
        "Which tool to take off the gateway: neuron, neurag or all. Empty = all."),
    ("gray-matter", "install", "client"): (
        "Dove registrare Gray Matter: 'all' (tutti), 'detected' (solo i client trovati) o il nome di un client.",
        "Where to register Gray Matter: 'all', 'detected' (only clients found) or a client name."),
    ("gray-matter", "register", "client"): (
        "In quali client AI: 'all', 'detected' (solo quelli trovati) o il nome di un client.",
        "Which AI clients: 'all', 'detected' (only those found) or a client name."),
    ("gray-matter", "register", "gateway"): (
        "Registra SOLO Gray Matter e toglie Neuron e NeuRAG diretti: tutto passa dal gateway.",
        "Registers ONLY Gray Matter and removes direct Neuron and NeuRAG: everything goes through the gateway."),
    ("gray-matter", "backup", "force"): (
        "Rifà la copia di oggi anche se esiste già.", "Redoes today's copy even if it already exists."),
    ("gray-matter", "bridges-transfer", "direction"): (
        "'to-cloud' copia i bridge locali nel cloud, 'from-cloud' il contrario. Aggiunge, non cancella.",
        "'to-cloud' copies local bridges to the cloud, 'from-cloud' the other way. Adds, never deletes."),
    ("gray-matter", "knowledge", "subcmd"): (
        "'status' = quanti nodi e collegamenti; 'rebuild-links' = ricalcola tutti i collegamenti; 'link-graph' = mostra il grafo.",
        "'status' = how many nodes and links; 'rebuild-links' = recompute every link; 'link-graph' = show the graph."),
    ("gray-matter", "reap", "reap_all"): (
        "Ferma TUTTI i processi seguiti, non solo quelli rimasti orfani.",
        "Stops EVERY tracked process, not just the orphaned ones."),
    ("gray-matter", "gm-neurag", "tool"): (
        "Nome dello strumento NeuRAG da chiamare, per esempio knowledge_query.",
        "Name of the NeuRAG tool to call, for example knowledge_query."),
    ("gray-matter", "gm-neurag", "args"): (
        'Parametri in JSON, per esempio {"query": "spring boot"}. Vuoto = nessuno.',
        'Parameters as JSON, for example {"query": "spring boot"}. Empty = none.'),
    ("gray-matter", "gm-neuron", "tool"): (
        "Nome dello strumento Neuron da chiamare, per esempio status o get_context.",
        "Name of the Neuron tool to call, for example status or get_context."),
    ("gray-matter", "gm-neuron", "args"): (
        'Parametri in JSON, per esempio {"topic": "caffè"}. Vuoto = nessuno.',
        'Parameters as JSON, for example {"topic": "coffee"}. Empty = none.'),
    ("gray-matter", "logs", "follow"): (
        "Continua a mostrare le righe nuove finché non premi Ferma.",
        "Keeps showing new lines until you press Stop."),
    ("gray-matter", "logs", "lines"): (
        "Quante righe finali mostrare. Vuoto = 50.", "How many last lines to show. Empty = 50."),
    ("gray-matter", "cloud", "subcmd"): (
        "'setup' crea i database, 'wire' collega database esistenti, 'status' mostra lo stato, 'teardown' torna al solo locale.",
        "'setup' creates the databases, 'wire' connects existing ones, 'status' shows the state, 'teardown' goes back to local only."),
    ("gray-matter", "cloud", "group"): (
        "Nome del gruppo Turso. Vuoto = graymatter.", "Turso group name. Empty = graymatter."),
    ("gray-matter", "cloud", "components"): (
        "Per 'setup': quali parti mettere in cloud, fra neuron, neurag, gm (separate da virgola). Vuoto = tutte.",
        "For 'setup': which parts go to the cloud, among neuron, neurag, gm (comma separated). Empty = all."),
    ("gray-matter", "cloud", "neuron_url"): (
        "Per 'wire': indirizzo del database di Neuron (libsql://…).",
        "For 'wire': address of Neuron's database (libsql://…)."),
    ("gray-matter", "cloud", "neurag_url"): (
        "Per 'wire': indirizzo del database di NeuRAG, diverso da quello di Neuron.",
        "For 'wire': address of NeuRAG's database, separate from Neuron's."),
    ("gray-matter", "cloud", "gm_url"): (
        "Per 'wire': indirizzo del database dei bridge di Gray Matter, separato dagli altri.",
        "For 'wire': address of Gray Matter's bridge database, separate from the others."),
    ("gray-matter", "cloud", "token"): (
        "Per 'wire': il token di accesso. Meglio lasciarlo vuoto: verrà chiesto senza mostrarlo.",
        "For 'wire': the access token. Better left empty: it will be asked without echoing."),
    ("gray-matter", "cloud", "env_file"): (
        "File .env dove salvare le impostazioni. Vuoto = quello di Gray Matter.",
        "The .env file to save settings in. Empty = Gray Matter's own."),
    ("gray-matter", "cloud", "no_cli_install"): (
        "Non proporre di installare il programma 'turso'.",
        "Never offer to install the 'turso' program."),
    ("gray-matter", "cloud", "yes"): (
        "Risponde 'sì' alla proposta di installare il programma 'turso'.",
        "Answers 'yes' to the offer to install the 'turso' program."),
    ("gray-matter", "collaborate", "name"): (
        "Quale tool: neuron o neurag.", "Which tool: neuron or neurag."),
    ("gray-matter", "isolate", "name"): (
        "Quale tool: neuron o neurag.", "Which tool: neuron or neurag."),
    ("gray-matter", "mode", "mode"): (
        "'collaborate' = i tool si scambiano contesto; 'separate' = ognuno per conto suo.",
        "'collaborate' = the tools share context; 'separate' = each on its own."),
    ("gray-matter", "promote", "apply"): (
        "Crea davvero i nodi in NeuRAG. Senza questa casella mostra solo cosa creerebbe.",
        "Actually creates the nodes in NeuRAG. Without this box it only shows what it would create."),
    ("neurag", "deregister", "client"): (
        "Da quale client AI: claude-desktop, claude-code, cursor, vscode, opencode o all. Vuoto = all.",
        "From which AI client: claude-desktop, claude-code, cursor, vscode, opencode or all. Empty = all."),
    ("neurag", "register", "client"): (
        "In quale client AI: claude-desktop, claude-code, cursor, vscode, opencode o all. Vuoto = all.",
        "In which AI client: claude-desktop, claude-code, cursor, vscode, opencode or all. Empty = all."),
    ("neurag", "register", "python_exe"): (
        "Quale Python usare per il server. Vuoto = quello installato (consigliato).",
        "Which Python runs the server. Empty = the installed one (recommended)."),
    ("neurag", "register", "force"): (
        "Registra NeuRAG direttamente anche se lo gestisce già Gray Matter (comparirà due volte).",
        "Registers NeuRAG directly even though Gray Matter already manages it (it will appear twice)."),
    ("neurag", "add-chunks", "node"): (
        "Il nodo a cui aggiungere i pezzi di testo.", "The node the text pieces are added to."),
    ("neurag", "add-chunks", "file"): (
        "File JSON con l'elenco dei pezzi di testo.", "JSON file with the list of text pieces."),
    ("neurag", "add-node", "name"): ("Nome del nuovo nodo.", "Name of the new node."),
    ("neurag", "add-node", "type"): (
        "'godnode' = argomento principale, 'fundamental' = sotto-argomento, 'specialization' = dettaglio.",
        "'godnode' = main topic, 'fundamental' = sub-topic, 'specialization' = detail."),
    ("neurag", "add-node", "parent"): (
        "Il nodo sotto cui metterlo. Vuoto = in cima.", "The node to put it under. Empty = at the top."),
    ("neurag", "add-node", "triggers"): (
        "Parole chiave che richiamano questo nodo.", "Keywords that bring this node up."),
    ("neurag", "archive", "name"): ("Il nodo da archiviare.", "The node to archive."),
    ("neurag", "archive", "restore"): (
        "Al contrario: riporta il nodo fra quelli attivi.", "The opposite: brings the node back to the active ones."),
    ("neurag", "chunk", "path"): (
        "Cartella o file da spezzare in pezzi di testo.", "Folder or file to split into text pieces."),
    ("neurag", "import", "mapping"): (
        "Percorso del file YAML che descrive nodi e documenti.",
        "Path of the YAML file describing nodes and documents."),
    ("neurag", "ingest", "path"): (
        "La cartella (o il singolo documento) da indicizzare.",
        "The folder (or single document) to index."),
    ("neurag", "ingest", "godnode"): (
        "Il nodo principale sotto cui metterla. Vuoto = il nome della cartella.",
        "The main node to put it under. Empty = the folder name."),
    ("neurag", "ingest", "code"): (
        "Indicizza anche i file di codice, non solo i documenti (.md .txt .pdf .docx).",
        "Also indexes source code files, not only documents (.md .txt .pdf .docx)."),
    ("neurag", "remove-node", "name"): (
        "Il nodo da cancellare (definitivo).", "The node to delete (permanent)."),
    ("neurag", "rename-node", "name"): ("Il nome attuale del nodo.", "The node's current name."),
    ("neurag", "rename-node", "new_name"): ("Il nuovo nome.", "The new name."),
    ("neurag", "query", "query"): (
        "L'argomento da cercare, in parole normali.", "The topic to search for, in plain words."),
    ("neurag", "recall", "query"): (
        "L'argomento da cercare, in parole normali.", "The topic to search for, in plain words."),
    ("neurag", "confirm", "names"): (
        "Due o più nomi di nodi, separati da spazio: il loro legame si rafforza.",
        "Two or more node names, separated by spaces: their link gets stronger."),
    ("neurag", "related", "name"): ("Il nodo di partenza.", "The starting node."),
    ("neurag", "related", "hops"): (
        "Quanti passi di distanza seguire. Vuoto = 2.", "How many steps away to follow. Empty = 2."),
    ("neurag", "related", "limit"): (
        "Quanti risultati al massimo. Vuoto = 10.", "At most how many results. Empty = 10."),
    ("neurag", "unpark", "name"): (
        "Il nodo parcheggiato da riattivare.", "The parked node to wake up."),
}


def arg_doc(tool: str, command: str, dest: str, lang: str = "it") -> str:
    """The plain-language meaning of an argument, or "" when nobody wrote one."""
    entry = ARG_DOCS.get((tool, command, dest)) or ARG_DOCS.get(dest)
    return (entry[1] if lang == "en" else entry[0]) if entry else ""



# I tre ambienti. `module` è ciò che si importa per sapere se il tool c'è.
ENVIRONMENTS = (
    {"key": "gray-matter", "label": "Gray Matter", "subtitle": "orchestratore",
     "subtitle_en": "orchestrator",
     "module": "gray_matter", "cli": "gray_matter.cli", "kind": "parser"},
    {"key": "neuron", "label": "Neuron", "subtitle": "memoria semantica",
     "subtitle_en": "semantic memory",
     "module": "neuron", "cli": "neuron.__main__", "kind": "commands"},
    {"key": "neurag", "label": "NeuRAG", "subtitle": "knowledge vault", "subtitle_en": "knowledge vault",
     "module": "neurag", "cli": "neurag.cli", "kind": "parser"},
)


def _version(module: str) -> str:
    """La versione che il CODICE dichiara, e solo in mancanza quella del dist-info.

    L'ordine era il contrario, e il dist-info e' una targa: `pip install -e` la
    scrive una volta e poi il codice va avanti da solo. Misurato 2026-09-09 su
    un'installazione editable sana: dist-info 6.4.2 contro `__version__` 6.4.4,
    e 1.4.1 contro 1.4.2 per Gray Matter. Nessuno dei due era rotto -- il
    dist-info diceva semplicemente la verita' di due settimane prima.

    Vale anche nel caso opposto, quello patologico: un install interrotto lascia
    il dist-info NUOVO sopra i file VECCHI, e li' la targa mente al rialzo. In
    entrambe le direzioni la risposta onesta e' il modulo importato, che e' il
    codice che gira davvero. E' lo stesso principio del CHANGELOG 6.4.2,
    "l'installer chiede al codice, non alla targa", qui applicato a chi quel
    numero lo mostra.

    Il dist-info resta il ripiego per il pacchetto che non espone
    `__version__`, e la stringa vuota per quello che non c'e' affatto.
    """
    try:
        v = getattr(importlib.import_module(module), "__version__", "")
        if v:
            return str(v)
    except Exception:  # noqa: BLE001 — non importabile: ci pensa il dist-info
        pass
    try:
        import importlib.metadata as md
        return md.version(module.replace("_", "-"))
    except Exception:  # noqa: BLE001 — non installato (es. checkout sorgente)
        return ""


def _installed(module: str) -> bool:
    try:
        return importlib.util.find_spec(module) is not None
    except BaseException:  # noqa: BLE001 — un pacchetto rotto = non installato
        return False


def _python() -> str:
    """Return the current Python executable path."""
    import sys
    return sys.executable or "python"


def _args_of(action_container) -> list[dict]:
    """Argomenti di un subparser, normalizzati per la GUI."""
    out = []
    for a in getattr(action_container, "_actions", []):
        if a.dest in ("help", "==SUPPRESS=="):
            continue
        out.append({
            "dest": a.dest,
            "flag": a.option_strings[0] if a.option_strings else "",
            "required": bool(getattr(a, "required", False)) and not a.option_strings,
            "choices": [str(c) for c in (a.choices or [])] if a.choices else [],
            "help": a.help or "",
            "is_flag": a.nargs == 0,
        })
    return out


def _from_parser(cli_module: str) -> list[dict]:
    mod = importlib.import_module(cli_module)
    parser = mod.build_parser()
    groups = getattr(mod, "COMMAND_GROUPS", {})
    subparsers = next((a for a in parser._actions
                       if hasattr(a, "choices") and isinstance(a.choices, dict)), None)
    if subparsers is None:
        return []
    cmds = []
    for name, sub in subparsers.choices.items():
        cmds.append({
            "name": name,
            "help": (sub.description or "").strip() or _help_of(subparsers, name),
            "group": groups.get(name, _DEFAULT_GROUP),
            "args": _args_of(sub),
        })
    return cmds


def _help_of(subparsers_action, name: str) -> str:
    for ch in subparsers_action._choices_actions:
        if ch.dest == name:
            return ch.help or ""
    return ""


def _from_commands(cli_module: str) -> list[dict]:
    """Neuron: dict `COMMANDS` = nome -> (modulo, funzione, gruppo, help, flag)."""
    mod = importlib.import_module(cli_module)
    return [{"name": name, "help": spec[3], "group": spec[2], "args": []}
            for name, spec in getattr(mod, "COMMANDS", {}).items()]


def environments(lang: str = "it") -> list[dict]:
    """Gli ambienti con lo stato reale della macchina. Mai solleva: un tool rotto
    compare come non-installato invece di far fallire tutta la GUI.

    lang: lingua delle descrizioni ("it" | "en") — la sceglie chi chiama, cioè
    la GUI, che sa quale lingua ha selezionato l'utente.

    Discovery order:
    1. GME folder (centralized registry)
    2. find_spec() fallback (existing behavior)
    """
    try:
        from gray_matter.gme import list_tools as gme_list_tools
        gme_tools = {t["key"]: t for t in gme_list_tools()}
    except ImportError:
        gme_tools = {}  # gme.py not available, fallback to find_spec
    
    out = []
    for env in ENVIRONMENTS:
        gme = gme_tools.get(env["key"])
        
        # Determine if installed
        if gme and gme.get("status") == "installed":
            present = True
            python_path = gme.get("python") or _python()
        else:
            present = _installed(env["module"])
            python_path = _python()
        
        commands: list[dict] = []
        error = ""
        if present:
            try:
                commands = (_from_parser(env["cli"]) if env["kind"] == "parser"
                            else _from_commands(env["cli"]))
            except BaseException as exc:  # noqa: BLE001 — anche SystemExit:
                # un tool la cui CLI chiama sys.exit() all'import non deve
                # uccidere la GUI, deve solo comparire con l'errore scritto.
                error = f"{type(exc).__name__}: {exc}"
        commands = [c for c in commands
                    if (env["key"], c["name"]) not in GUI_HIDDEN]
        for c in commands:
            key = (env["key"], c["name"])
            what, when = doc_for(key, lang)
            # il testo argparse resta il fallback: un subcomando nuovo compare
            # nella GUI anche prima che qualcuno lo abbia descritto qui.
            c["help"] = what or c["help"]
            c["when"] = when
            c["interactive"] = key in INTERACTIVE
            c["section"] = section_of(env["key"], c["name"], c["group"])
            c["args"] = [a for a in c["args"] if a["dest"] not in GUI_HIDDEN_ARGS]
            for a in c["args"]:
                a["doc"] = arg_doc(env["key"], c["name"], a["dest"], lang) or a["help"]
        
        # Versione: prima il CODICE, il registro solo come ripiego.
        #
        # Era il contrario, e il registro GME e' un'etichetta scritta una volta
        # sola all'installazione: non lo aggiorna nessuno. Osservato 2026-09-09
        # su una macchina con neuron 6.4.4 installato e funzionante — la GUI
        # diceva 6.4.2, la versione del 17 agosto, e per Gray Matter si
        # contraddiceva da sola: 1.4.2 nell'intestazione (letta dal codice) e
        # 1.4.1 in sidebar (letta dal registro).
        #
        # E' lo stesso difetto per cui esiste `test_wiring_catches_a_label_that
        # _lies_about_the_code`: chi si fida della targa invece che del motore
        # vede aggiornato cio' che non lo e'. Su un pannello che serve a capire
        # SE un aggiornamento e' andato a buon fine, e' il numero peggiore da
        # sbagliare.
        #
        # Il registro resta il ripiego: un tool installato ma non importabile
        # da QUESTO interprete non ha un `_version()` da offrire, e li' l'unica
        # cosa che sappiamo e' quello che il registro ricorda.
        version = _version(env["module"]) if present else ""
        if not version and gme and gme.get("version"):
            version = gme["version"]
        
        out.append({
            "key": env["key"], "label": env["label"],
            "subtitle": env["subtitle_en"] if lang == "en" else env["subtitle"],
            "installed": present, "version": version,
            "venv": gme.get("venv") if gme else None,
            "python": python_path,
            "linked_to": gme.get("linked_to") if gme else None,
            "commands": sorted(commands, key=lambda c: (
                [g[0] for g in GROUPS].index(c["group"])
                if c["group"] in [g[0] for g in GROUPS] else 99, c["name"])),
            "error": error or (gme.get("error") if gme else None),
        })
    return out


def grouped(env: dict) -> list[dict]:
    """I comandi di un ambiente raccolti per gruppo, nell'ordine di GROUPS."""
    out = []
    for key, label in GROUPS:
        items = [c for c in env["commands"] if c["group"] == key]
        if items:
            out.append({"key": key, "label": label, "commands": items})
    return out


def demo() -> None:
    """Self-check: il catalogo deve descrivere la macchina, non un elenco fisso."""
    envs = environments()
    assert len(envs) == 3, envs
    gm = next(e for e in envs if e["key"] == "gray-matter")
    assert gm["installed"], "gray_matter deve essere importabile da qui"
    assert not gm["error"], gm["error"]
    names = [c["name"] for c in gm["commands"]]
    assert "status" in names and "install" in names, names
    # ogni comando finisce in un gruppo noto: nessuno sparisce dalla GUI
    valid = {g[0] for g in GROUPS}
    for e in envs:
        for c in e["commands"]:
            assert c["group"] in valid, (e["key"], c)
        assert sum(len(g["commands"]) for g in grouped(e)) == len(e["commands"]), e["key"]

    # Ogni voce di DOCS deve avere tutte e quattro le parti piene: una lingua a
    # metà è peggio di una assente, perché la GUI la mostra comunque.
    for key, entry in DOCS.items():
        assert len(entry) == 4, key
        for part in entry:
            assert part and part.strip(), f"{key}: pezzo vuoto in DOCS"

    # Nessun comando visibile deve restare senza guida scritta, in NESSUNA
    # delle due lingue: è il controllo che tiene onesto "tutti i comandi
    # documentati" quando qualcuno ne aggiunge uno nuovo alla CLI.
    for lang in ("it", "en"):
        for e in environments(lang):
            for c in e["commands"]:
                key = (e["key"], c["name"])
                assert key in DOCS, f"comando senza guida [{lang}]: {key}"
                assert c["when"], f"manca il 'quando serve' [{lang}]: {key}"

    # DOCS non deve descrivere comandi che non esistono più.
    real = {(e["key"], c["name"]) for e in envs for c in e["commands"]}
    stale = {k for k in DOCS if k[0] in {e["key"] for e in envs if e["installed"]}} - real
    assert not stale, f"DOCS descrive comandi inesistenti: {sorted(stale)}"
    print(f"catalog OK — " + ", ".join(
        f"{e['label']}: {len(e['commands'])} comandi" if e["installed"]
        else f"{e['label']}: non installato" for e in envs))


if __name__ == "__main__":
    demo()
