"""Gray-Matter MCP server — proxy + orchestrator.

Runs as a stdio MCP server that:
1. Accepts tool calls from the client
2. Routes them to the right registered MCP server (Neuron, NeuRAG)
3. Returns the response to the client
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import socket
import struct
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from mcp.server.lowlevel import Server
from mcp.server.models import InitializationOptions
from mcp.types import Tool, TextContent

from gray_matter import __version__
from gray_matter.cache import ContextCache
from gray_matter.registry import Registry
from gray_matter import settings as _settings

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Tunable knobs (see `gray-matter config`): read once at startup — `config set`
# takes effect on the next restart. Missing/unknown keys fall back to defaults.
_cfg = _settings.load()

# SSOT in cli.py: la CLI (e la GUI) devono conoscere host/porta SENZA
# importare questo modulo, che trascina `mcp` e tutto il server.
# _send_ipc/_recv_exact vivono in cli.py con host e porta (stesso SSOT). Qui ne
# esisteva una COPIA sincrona, resa irraggiungibile dall'omonima `async
# _recv_exact` definita più sotto: Python risolve i globali alla chiamata, così
# `_send_ipc` finiva per invocare la coroutine con 2 argomenti su 3 →
# TypeError. Effetto: _send_heartbeat/_send_registration fallivano SEMPRE →
# NeuRAG standalone moriva all'avvio (autoregister non è protetto) e Neuron non
# si registrava mai al gateway, in silenzio. Una copia sola, importata.
from gray_matter.cli import (GRAY_MATTER_HOST, GRAY_MATTER_PORT,  # noqa: E402
                             GRAY_MATTER_PORT_SPAN, resolve_port, write_port_file,
                             clear_port_file, port_is_free, gm_answers,
                             _send_ipc, IPC_TOOL_TIMEOUT)
from gray_matter import ipcauth as _ipcauth  # noqa: E402
HEARTBEAT_INTERVAL = _cfg["heartbeat_interval"]  # seconds
HEARTBEAT_TIMEOUT = 15.0  # seconds — after 3 missed beats, mark dead
IDLE_SLEEP_TIMEOUT = _cfg["idle_sleep_timeout"]  # sleep after this long idle

# ---------------------------------------------------------------------------
# IPC helpers (tiny TCP-based protocol for server <-> Gray-Matter)
# ---------------------------------------------------------------------------

def _send_registration(name: str, tool_names: list[str], socket_path: str, pid: int) -> dict:
    """Register this server with Gray-Matter."""
    return _send_ipc({
        "action": "register",
        "name": name,
        "tool_names": tool_names,
        "socket_path": socket_path,
        "pid": pid,
    })


def _send_heartbeat(name: str) -> dict:
    """Send a heartbeat ping."""
    return _send_ipc({
        "action": "heartbeat",
        "name": name,
    })


def _is_gray_matter_running() -> bool:
    """True only when a GM actually answers on (host, port) (ping probe, not a
    blind TCP connect): the `port` file can be stale after a reboot, and a
    foreign listener on that port made start/ping say "already running" while
    every real IPC call failed."""
    return gm_answers(GRAY_MATTER_HOST, resolve_port())


def autoregister(name: str, tool_names: list[str]) -> bool:
    """Auto-register with a running Gray-Matter. Returns True on success.

    If Gray-Matter is not running, spawns one first.
    Then registers this server.
    """
    # Spawn Gray-Matter if not running
    if not _is_gray_matter_running():
        _spawn_gray_matter()

    # Register (retry up to 3 times — race with spawn)
    pid = os.getpid()
    socket_path = f"tcp://{GRAY_MATTER_HOST}:{os.getpid() + 50000}"  # dummy, placeholder
    for attempt in range(3):
        result = _send_registration(name, tool_names, socket_path, pid)
        if "error" not in result:
            return True
        time.sleep(0.3)
    return False


def daemon_log_path():
    """Il log del daemon (G2): stdout+stderr del processo finiscono qui."""
    from gray_matter.paths import logs_dir
    return logs_dir() / "daemon.log"


def _spawn_gray_matter() -> None:
    """Spawn Gray-Matter as a background process."""
    # Use python -m gray_matter.server to run the server module
    # Detach from parent process so it survives parent death
    cmd = [sys.executable, "-u", "-m", "gray_matter.server", "--daemon"]  # -u: log senza buffering
    creationflags = 0
    if sys.platform == "win32":
        # NIENTE DETACHED_PROCESS. Windows IGNORA CREATE_NO_WINDOW quando è
        # combinato con DETACHED_PROCESS (o CREATE_NEW_CONSOLE), e il figlio
        # staccato si alloca una console TUTTA SUA — la finestra CMD vuota che
        # compariva a ogni `gray-matter start`. Misurato sul posto:
        #   CREATE_NO_WINDOW | DETACHED_PROCESS -> console visibile
        #   CREATE_NO_WINDOW                    -> nessuna console
        #   CREATE_NO_WINDOW | NEW_PROCESS_GROUP-> nessuna console
        # DETACHED_PROCESS non serviva comunque a far sopravvivere il daemon:
        # su Windows i figli non muoiono col padre (non c'è kill dell'albero
        # senza un Job object). Il gruppo separato serve solo a NON prendere il
        # Ctrl-C della console che l'ha avviato.
        creationflags = (subprocess.CREATE_NO_WINDOW
                         | subprocess.CREATE_NEW_PROCESS_GROUP)

    # G2: stdout/stderr → logs/daemon.log (append) invece del buco nero — ogni
    # print e traceback diventa leggibile con `gray-matter logs [--follow]`.
    # Fallback DEVNULL se il file non è apribile (mai bloccare lo spawn).
    try:
        log_path = daemon_log_path()
        log_path.parent.mkdir(parents=True, exist_ok=True)
        out = open(log_path, "a", encoding="utf-8", errors="replace")  # noqa: SIM115
        out.write(f"\n--- spawn {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
        out.flush()
    except OSError:
        out = None
    stdout_err = out if out is not None else subprocess.DEVNULL
    # cwd: a folder of ours, never the caller's. `-m` puts the current folder
    # first on sys.path, so a daemon started from the repo root imported
    # gray_matter and neurag from the SOURCE, and its workers inherit it
    # (seen 2026-11-08: neurag/embedder.py loaded from the checkout).
    from gray_matter.paths import gm_home
    home = gm_home()
    try:
        home.mkdir(parents=True, exist_ok=True)
    except OSError:
        home = Path(sys.executable).parent
    try:
        subprocess.Popen(
            cmd,
            cwd=str(home),
            creationflags=creationflags,
            stdin=subprocess.DEVNULL,
            stdout=stdout_err,
            stderr=stdout_err,
        )
    finally:
        if out is not None:
            out.close()  # parent FD closed; child inherited it


# ---------------------------------------------------------------------------
# Gray-Matter MCP Server
# ---------------------------------------------------------------------------

_registry = Registry.instance()
_last_call_time: float = time.time()
_flash_counter: int = 0

# ONE shared context cache. It used to be re-created inside every pulse, so it
# never hit — a silent "cache that never caches" bug. A single instance persists
# across calls and makes `gray-matter stats` hit-rate meaningful.
_ctx_cache = ContextCache(max_size=_cfg["cache_max_size"], ttl=_cfg["cache_ttl_seconds"])

# Lightweight observability counters, surfaced by `gray-matter stats` / `doctor`.
_stats: dict[str, float] = {"pulses": 0, "cache_hits": 0, "cache_misses": 0,
                            "flashes": 0, "bridges_added": 0, "pulse_ms_total": 0.0,
                            "kb_hints": 0}
# Calls per tool this session (model-initiated only, not GM's internal
# lookups): how many knowledge_query a pointer provokes was a feeling until now.
_tool_calls: dict[str, int] = {}

# D4 — conversation buffer: gli ultimi topic della sessione. Ogni pulse espande
# la query NeuRAG col contesto recente (recall migliore su domande incrementali);
# Neuron non ne ha bisogno (ha già la sua context window interna).
from collections import deque as _deque
_topic_buffer: "_deque[str]" = _deque(maxlen=3)


def _remember_topic(topic: str) -> None:
    if topic in _topic_buffer:          # ri-chiesto → torna in cima
        _topic_buffer.remove(topic)
    _topic_buffer.append(topic)


# Flash v1: fire on a topic shift (serendipity at transitions), rate-limited.
_last_topic: str = ""
_flashed: set = set()          # concepts already flashed this session (cooldown)
_calls_since_flash: int = 0
FLASH_MIN_GAP = _cfg["flash_min_gap"]   # min pulses between flashes (anti-spam)


# Quanto contesto GM inietta. Il punto del progetto è far RISPARMIARE token, e
# fino a qui la quantità era un effetto collaterale: il blocco proattivo (bridge,
# vicini, flash) non aveva alcun tetto, e 40 bridge che condividevano un tag
# facevano ~5000 token in una sola pulse. Ora è un budget, regolabile dalla GUI.
KNOWLEDGE_TOP_N = _cfg["knowledge_top_n"]
MEMORY_MAX_TOKENS = _cfg["memory_max_tokens"]
PROACTIVE_BUDGET = _cfg["proactive_budget_chars"]
# Quanti bridge al massimo per pulse. Non è un knob: il budget in caratteri è
# già la manopola: questo è solo la difesa che evita di RINFORZARE (e quindi
# promuovere) decine di bridge per poi scartarne il testo.
_BRIDGES_PER_PULSE = 5
# Quanto razionale mostrare per bridge. Lo store ne accetta 500 caratteri perché
# lì è documentazione che un umano legge in `gray-matter bridges`; iniettarli
# interi in una pulse voleva dire spendere il budget su cinque paragrafi.
_BRIDGE_WHY_CHARS = 80


async def _do_promote(apply: bool = False) -> dict:
    """CLS consolidation, dry run unless `apply` (§5.3, §8.2).

    Reads Neuron through its `export` tool and writes NeuRAG through
    `knowledge_add_node`: two public surfaces, no vault opened here.
    """
    import json as _json

    from gray_matter import promote as _promote

    try:
        raw = await _call_server_async("neuron", "export", {})
        export = _json.loads(raw)
    except Exception as exc:  # noqa: BLE001
        return {"error": f"Neuron unreachable or export unreadable: {exc}"}

    # ADR-016 D8: facts, not nodes. A fact already in the vault has its
    # `#id <-> node` bridge: that bridge is the record, so it is never re-added.
    from gray_matter.bridges import add_bridge, all_bridges
    promoted_ids = {b["neuron"][1:] for b in all_bridges() if str(b["neuron"]).startswith("#")}
    cands = _promote.candidates(export, promoted=promoted_ids)
    written, skipped, already, chunks_written = [], [], [], 0
    if apply and cands:
        # One godnode for everything that comes from memory: the vault tree
        # keeps the ingested documents on one side, the promoted memory on the other.
        try:
            await _call_server_async("neurag", "knowledge_add_node", {
                "name": _promote.PROMOTE_PARENT, "node_type": "godnode",
                "triggers": ["memoria", "promosso", "promote", "neuron"]})
        except Exception as exc:  # noqa: BLE001 — "already exists" arrives as text, not as an error
            return {"error": f"godnode '{_promote.PROMOTE_PARENT}' could not be created: {exc}"}
        for c in cands:
            try:
                # A node that already exists is reused: new facts of a promoted
                # concept join it (the old rule skipped them forever).
                res = str(await _call_server_async("neurag", "knowledge_add_node", {
                    "name": c["keyword"], "node_type": "fundamental",
                    "parent_name": _promote.PROMOTE_PARENT,
                    "triggers": c["tags"] or [c["keyword"]],
                })).lower()
                if "not found" in res:
                    skipped.append(c["keyword"])
                    continue
                (already if "already exists" in res else written).append(c["keyword"])
                await _call_server_async("neurag", "knowledge_add_chunks", {
                    "node_name": c["keyword"], "chunks": c["chunks"]})
                chunks_written += len(c["chunks"])
                for fid, ch in zip(c["facts"], c["chunks"]):
                    add_bridge(f"#{fid}", c["keyword"], f"promoted {ch['section']}", promoted=True)
            except Exception as exc:  # noqa: BLE001 — one broken node does not stop the rest
                skipped.append(f"{c['keyword']}: {exc}")
    return {"applied": apply, "count": len(cands), "candidates": cands,
            "written": written, "already": already, "skipped": skipped,
            "chunks": chunks_written, "rules": _promote.PROMOTE_RULES}


def _fit(budget: int, blocks: list[str]) -> tuple[str, int]:
    """Take blocks in priority order, keeping each that still fits in `budget`.

    Trims by BLOCK, never mid-sentence: half a bridge line costs the same
    context as a whole one and reads like a bug. Returns the joined text and how
    many blocks were dropped, so the caller can say so instead of the reader
    wondering.

    A block too big to fit is SKIPPED, not a stop signal — a later, smaller one
    still gets in. These are independent hints, so more of them inside the same
    budget is worth more than a strict prefix of the priority order."""
    kept, used, dropped = [], 0, 0
    for b in blocks:
        if not b:
            continue
        if used + len(b) > budget:
            dropped += 1
            continue
        kept.append(b)
        used += len(b)
    return "\n\n".join(kept), dropped


async def _bridge_blocks(topic: str, neurag_tags: set, limit: int) -> list[str]:
    """Cross-store bridges for this topic, one per block, strongest first.

    The limit is also the limit on REINFORCEMENT: showing a bridge is what
    counts as using it, so what does not fit is not reinforced. One bridge per
    block so the budget packs as many as fit instead of dropping them all. The
    rationale is TRUNCATED: the store keeps 500 chars because there it is
    documentation; here it is an injected hint, and five whole rationales alone
    blew the budget and took every bridge down with them. Showing confirms
    nothing in Neuron any more (ADR-016 D5)."""
    from gray_matter.bridges import bridges_for
    rel = bridges_for(topic, tags=neurag_tags, limit=limit)
    out: list[str] = []
    for b in rel:
        why = (b.get("rationale") or "").strip()
        if len(why) > _BRIDGE_WHY_CHARS:
            why = why[:_BRIDGE_WHY_CHARS - 1].rstrip() + "…"
        out.append(f"🔗 {b['neuron']} ↔ {b['neurag']}" + (f" — {why}" if why else ""))
    return out


# --- Knowledge on pre_turn (2026-09-12, vector since 2026-11-05) ------------
# The model calls pre_turn every turn and pulse never: on a real vault test the
# KB was indexed, bridged, and consulted zero times in the whole session. So the
# KB rides the call that actually happens: ONE pointer line ("the KB has this
# section, ask knowledge_query") plus the bridges for the topic, inside the
# proactive budget. The content stays behind an explicit knowledge_query.
#
# The pointer was a SQL name/trigger lookup (knowledge_neighbors) until
# 2026-11-05. Measured on five real messages it named a WHOLE FOLDER every time
# ("audit", "docs", "gray_matter") and minted false bridges (flash<->audit,
# flusso<->docs); the vector search named the right section three times and was
# silent below its threshold. See _kb_vector_pointer and ADR-014 D3.
_KB_HINTS_PER_TURN = 1          # bridges shown next to the pointer; tokens, not a knob
_KB_HINT_SHOWN: set = set()     # sections already pointed at this session: once each.
                                # A repeat is ~25 tokens that invite a ~1000-token
                                # knowledge_query the model already chose to make or not.


async def _knowledge_hint(arguments: dict, shown: "set | None" = None) -> str:
    """The KB addendum for a pre_turn: one vector pointer (_kb_vector_pointer)
    plus the bridges already persisted for the topic. Empty when NeuRAG is off,
    isolated, the budget is zero, or nothing clears the threshold.

    `shown`: the sections already pointed at. A gateway serves one session and
    uses the module's; the daemon serves many and passes one per session."""
    shown = _KB_HINT_SHOWN if shown is None else shown
    neurag = _registry.get_server("neurag")
    if not (neurag and neurag.is_alive() and neurag.collaborative) or PROACTIVE_BUDGET <= 0:
        return ""
    topic = " ".join(str(arguments.get("topic", "")).split())[:200]
    kws = [str(k).strip() for k in (arguments.get("keywords") or []) if str(k).strip()]
    blocks: list[str] = []
    pointer = await _kb_vector_pointer(" ".join([topic, *kws[:5]])[:300], shown)
    if pointer:
        blocks.append(pointer.strip())
        _stats["kb_hints"] += 1
    blocks.extend(await _bridge_blocks(topic, set(), _KB_HINTS_PER_TURN))
    extra, _dropped = _fit(PROACTIVE_BUDGET, blocks)
    return ("\n\n" + extra) if extra else ""


_is_sleeping: bool = False

# version= explicitly: without it the SDK reports ITS OWN version in the
# handshake, so a client asking which Gray Matter it is talking to was told
# "1.28.1" — the MCP library's number. Both peers already pass it.
app = Server("gray-matter", version=__version__)

# MCP handshake instructions (INSTALLER-UX §8b): the loop-guidance for clients
# that honor `instructions` (Cursor/VS Code/Codex) — no hook needed there. The
# per-client hooks stay for clients that ignore this field. Keep in sync with
# Neuron/clients/claude-code-hook (same loop, GM-gateway flavored).
GM_INSTRUCTIONS = (
    "Gray-Matter gateway: Neuron (persistent semantic memory) + NeuRAG (knowledge "
    "base) behind one proxy — their tools are served here pass-through.\n"
    "Each substantive turn: call pre_turn(topic, keywords) BEFORE replying (fold "
    "the returned context in silently), then store_turn(facts=[{kind, text, "
    "concepts}], English only) AFTER, for what is worth not repeating: progress, decisions, fixes, details, ideas, the user and their habits; not what git or the project files already record. "
    "knowledge_query(query) searches the user's own documents.\n"
    "store_turn(context=<the ctx= of the latest [neuron] recall header>): one gateway serves several sessions. "
    "Concepts = 1-5 NOUNS per fact (no verbs/paths); an update passes "
    "supersedes=<#id>; links typed, never a "
    "self-link; a near-duplicate fact is flagged when stored; never store "
    "secrets or tokens. Skip on procedural turns (ack/thanks/yes-no)."
)


  # server_name -> consecutive failures


_subservers_ready = False


async def _ensure_subservers() -> None:
    """Register Neuron/NeuRAG once per process, however `app` is served.

    Only the stdio main() ran `_bootstrap_subservers`. The HTTP bridges import
    `app` and serve it directly, so a remote client saw GM's own 7 tools and
    none of Neuron's or NeuRAG's — a bridge that "worked" with most of the
    suite missing, measured 2026-10-24. Once, like main(): a sub-server that
    fails here is retried by the same paths that retry it under stdio."""
    global _subservers_ready
    if not _subservers_ready:
        _subservers_ready = True
        await _bootstrap_subservers()


@app.list_tools()
async def list_tools() -> list[Tool]:
    """Dynamically list tools from all registered servers."""
    await _ensure_subservers()
    tools = []

    # Gray Matter's own tools (pulse, status, bridge) are
    # upkeep: callable by name, announced only with GM_TOOLS=all. The model sees
    # the I/O contract (work/design/CONTRATTO-IO-2026-11-14.md): pre_turn,
    # store_turn, switch_context, knowledge_query.
    own: list[Tool] = []
    own.append(Tool(
        name="gray_matter_pulse",
        description="The richer explicit read: Neuron's facts for the topic (as pre_turn), NeuRAG's knowledge excerpts, saved bridges and a flash, in one call.",
        inputSchema={
            "type": "object",
            "properties": {
                "topic": {"type": "string", "description": "Topic to search for"},
                "top_n": {
                    "type": "integer", "description": "Number of chunks (default 5)",
                    "default": 5, "minimum": 1, "maximum": 10,
                },
            },
            "required": ["topic"],
        },
    ))
    own.append(Tool(
        name="gray_matter_status",
        description="Show Gray-Matter status: registered servers, cache, counters.",
        inputSchema={"type": "object", "properties": {}},
    ))
    own.append(Tool(
        name="gray_matter_bridge",
        description="Persist a cross-store bridge: a link between a Neuron concept and a NeuRAG knowledge node the orchestrator found to relate. Recalled in future pulses on either endpoint.",
        inputSchema={
            "type": "object",
            "properties": {
                "neuron_concept": {"type": "string", "description": "Neuron concept/keyword"},
                "neurag_node": {"type": "string", "description": "NeuRAG node/topic"},
                "rationale": {"type": "string", "description": "Why they connect"},
            },
            "required": ["neuron_concept", "neurag_node"],
        },
    ))

    if os.environ.get("GM_TOOLS", "core").lower() == "all":
        tools.extend(own)

    # Tools from registered servers (F12: re-publish REAL schemas, fetched once
    # from each worker and cached; fall back to an empty schema if unavailable so
    # list_tools never blocks on a cold/broken worker).
    for server in _registry.alive_servers():
        await _ensure_schemas(server)
        for tool_name in server.tool_names:
            meta = server.tool_schemas.get(tool_name) or {}
            tools.append(Tool(
                name=tool_name,
                description=meta.get("description") or f"({server.name}) {tool_name}",
                inputSchema=meta.get("inputSchema") or {"type": "object", "properties": {}},
            ))

    return tools


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    global _last_call_time, _flash_counter

    await _ensure_subservers()
    _last_call_time = time.time()
    _flash_counter += 1
    _tool_calls[name] = _tool_calls.get(name, 0) + 1

    # --- Gray-Matter orchestrated tools ---

    if name == "gray_matter_pulse":
        global _is_sleeping
        _is_sleeping = False
        # Validate the topic (mirror of the bridge ingest guard): coerce, strip,
        # collapse whitespace, cap. Empty/whitespace-only -> nothing to search.
        topic = " ".join(str(arguments.get("topic", "")).split())[:200]
        if not topic:
            return [TextContent(type="text", text="pulse: empty topic.")]
        top_n = min(max(int(arguments.get("top_n", KNOWLEDGE_TOP_N)), 1), 10)
        _t0 = time.monotonic()
        _stats["pulses"] += 1
        _remember_topic(topic)   # D4: conversation buffer (anche sui cache hit)

        # Cache hit? (one shared cache — see _ctx_cache)
        cached = _ctx_cache.get(topic)
        if cached is not None:
            _stats["cache_hits"] += 1
            return [TextContent(type="text", text=cached)]
        _stats["cache_misses"] += 1

        # Collect calls to registered servers (track which is which for v3b).
        tasks, labels = [], []

        neuron = _registry.get_server("neuron")
        if neuron and neuron.is_alive() and neuron.collaborative:
            # ADR-016 D1: the same read as pre_turn and the hook — facts, not
            # node names (get_context gave 10 links, 6 names and zero facts on
            # a question whose fact pre_turn put first).
            n_args = {"topic": topic, "max_tokens": MEMORY_MAX_TOKENS,
                      "exclude": sorted(_flashed)}
            await _resolve_session_ctx()
            tasks.append(_call_server_async("neuron", "pre_turn", _session_scoped("pre_turn", n_args)))
            labels.append("neuron")

        neurag = _registry.get_server("neurag")
        if neurag and neurag.is_alive() and neurag.collaborative:
            # D4 — multi-turn RAG: espandi la query NeuRAG con i topic recenti
            # (Neuron ha già la sua context window; la cache resta keyed sul
            # topic puro, quindi l'espansione non inquina i cache hit).
            recent = [t for t in _topic_buffer if t != topic]
            rag_query = topic + (" " + " ".join(recent) if recent else "")
            tasks.append(_call_server_async("neurag", "knowledge_query", {"query": rag_query[:300], "top_n": top_n})); labels.append("neurag")

        if not tasks:
            return [TextContent(type="text", text="No servers available for pulse.")]

        # Parallel execution
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Auto-build cross-links once: if NeuRAG has nodes but zero links,
        # rebuild so future queries get link enrichment. One-shot per session.
        global _neurag_links_built
        if not _neurag_links_built and "neurag" in labels:
            try:
                status_raw = await _call_server_async("neurag", "knowledge_status", {})
                import json as _json
                ns = _json.loads(status_raw) if isinstance(status_raw, str) else status_raw
                if ns.get("links", 0) == 0 and ns.get("nodes", 0) > 1:
                    await _call_server_async("neurag", "knowledge_rebuild_links", {})
            except Exception:  # noqa: BLE001
                pass
            _neurag_links_built = True

        context_parts = []
        for lbl, r in zip(labels, results):
            if isinstance(r, Exception):
                context_parts.append(f"[error: {r}]")
            elif r:
                context_parts.append(r)
                if lbl == "neuron":
                    _note_facts(r, _flashed)

        response = "\n---\n".join(context_parts) if context_parts else "No results."

        # Everything below is PROACTIVE: nobody asked for it, so it lives inside
        # `proactive_budget_chars`. At 0 the pulse is only the real answers.
        proactive: list[str] = []

        # Cross-store bridges persisted for this topic, matched on whole tokens.
        if PROACTIVE_BUDGET > 0:
            proactive.extend(await _bridge_blocks(topic, set(), _BRIDGES_PER_PULSE))

        # Flash: serendipitous dormant-concept recall, fired at a topic shift.
        if PROACTIVE_BUDGET > 0:
            # ADR-016 D4: no bridge is born from a flash any more.
            flash_note, _concept = await _maybe_flash(topic, scope=_SESSION_CTX[0] or "")
            if flash_note:
                proactive.append(flash_note)

        # The flash goes first: it is the only proactive content that cannot be
        # asked for again (bridges are in `gray-matter bridges`). A cut flash is lost.
        extra, dropped = _fit(PROACTIVE_BUDGET, list(reversed(proactive)))
        if extra:
            response += "\n\n" + extra
        if dropped:
            response += (f"\n\n(+{dropped} leads left out: proactive budget "
                         f"{PROACTIVE_BUDGET} chars — `gray-matter config set "
                         f"proactive_budget_chars <n>`)")

        # Cache + record the real-work latency (this was a miss).
        _ctx_cache.set(topic, response)
        _stats["pulse_ms_total"] += (time.monotonic() - _t0) * 1000

        return [TextContent(type="text", text=response)]

    if name == "gray_matter_status":
        lines = [
            f"Gray-Matter v{__version__}",
            f"Flash counter: {_flash_counter}",
            f"Servers: {len(_registry.all_servers())}",
            _registry.summary(),
        ]
        return [TextContent(type="text", text="\n".join(lines))]

    if name == "gray_matter_bridge":
        from gray_matter.bridges import add_bridge
        node = " ".join(str(arguments.get("neurag_node", "")).split())
        # ADR-016 D4: the NeuRAG end must be a node that exists, by its exact
        # name (bridges were born pointing at the question's text).
        try:
            found = (json.loads(await _call_server_async(
                "neurag", "knowledge_neighbors", {"query": node, "depth": 1, "limit": 1}))
                .get("node") or {}).get("name") or ""
        except Exception as exc:  # noqa: BLE001 — no NeuRAG: nothing to bridge to
            return [TextContent(type="text", text=f"Bridge not saved: NeuRAG unavailable ({exc}).")]
        if found.lower() != node.lower():
            hint = f" Did you mean '{found}'?" if found else ""
            return [TextContent(type="text", text=f"Bridge not saved: no NeuRAG node named '{node}'.{hint}")]
        created = add_bridge(arguments.get("neuron_concept", ""), found, arguments.get("rationale", ""))
        return [TextContent(type="text", text="Bridge saved." if created
                            else "Bridge reinforced (it already existed), or an endpoint was invalid.")]



    # A write to episodic memory can make a cached pulse stale: drop the entries
    # for the just-written topic so the next pulse rebuilds fresh (targeted, not a
    # full flush — other topics keep their cache).
    if name == "store_turn":
        _ctx_cache.invalidate_related(str(arguments.get("topic", "")))

    # --- Route to registered server (pass-through) ---
    # Unannounced tools (the tool diet hides upkeep/admin ones from list_tools)
    # still route by name: the worker dispatches by name and answers itself
    # when a tool really does not exist.
    server = (_registry.find_server_by_tool(name)
              or _registry.get_server("neurag" if name.startswith("knowledge_") else "neuron"))
    if server is None:
        return [TextContent(type="text", text=f"Tool '{name}' not found in any registered server.")]

    # ADR-015 D7.1 for clients without the hook: a stdio gateway lives as long
    # as its client's session, so its first pre_turn carries the profile.
    global _PROFILE_SENT
    if server.name == "neuron" and name == "pre_turn":
        arguments = {**arguments, "exclude": sorted(_flashed),
                     "profile": not (_PROFILE_SENT or _client_has_memhook())}
        _PROFILE_SENT = True

    if server.name == "neuron":
        await _resolve_session_ctx()
        arguments = _session_scoped(name, arguments)

    if server.name == "neuron" and name == "store_turn":
        try:      # who writes the fact: Neuron sees only this gateway as its client
            arguments = {**arguments, "by": app.request_context.session.client_params.clientInfo.name or ""}
        except Exception:  # noqa: BLE001 — no request context: Neuron falls back to "model"
            pass

    result = await _call_server_async(server.name, name, arguments)
    if server.name == "neuron" and name == "pre_turn":
        _note_facts(result, _flashed)
    # The KB travels on the call the model really makes (see _knowledge_hint).
    is_pre = server.name == "neuron" and name == "pre_turn"
    kb = (await _knowledge_hint(arguments) if is_pre else "")
    # The flash travels on the same call (ADR-014 phase 4): the model calls
    # pre_turn, not pulse, and a spontaneous recall cannot wait for a call
    # nobody makes. For clients with the hook, "recall" already gives it.
    flash = ""
    if is_pre and PROACTIVE_BUDGET > 0:
        flash, _c = await _maybe_flash(str(arguments.get("topic", "")), scope=str(arguments.get("_scope") or ""))
        flash = _unless_shown(flash, result or "")
        flash = f"\n\n{flash}" if flash else ""
    return [TextContent(type="text", text=(result or "(empty)") + kb + flash)]


# Persistent workers: one long-lived subprocess per server (imported once, model
# kept warm) instead of a cold-import subprocess per call. See gray_matter/_worker.py.
_workers: dict = {}          # server_name -> Popen
_worker_locks: dict = {}     # server_name -> asyncio.Lock (serialize the shared pipe)
_worker_lat: dict = {}       # server_name -> {calls, ms_total, last_ms} (tempo NEL tool)
_prewarmed: set = set()      # servers already warmed (D2), so we warm each once
_neurag_links_built: bool = False  # auto-build links once when links=0 and nodes>1

# Cheap read fired to warm a worker: spawns the subprocess (pays the import) and
# loads the model (Neuron's fastembed) BEFORE the first real pulse, so that pulse
# isn't the one paying the ~cold-start tax. Unknown servers get import-warm only.
_WARM_TOOL = {
    # ADR-016 D6: load the model AND the recall vectors at startup, not at the
    # first message (44 s on a cold cache, 2026-11-08). forgotten(facts) has no
    # side effect.
    "neuron": ("forgotten", {"facts": True, "near": "warmup", "top_n": 1}),
    "neurag": ("knowledge_query", {"query": "warmup", "top_n": 1}),
}


async def _prewarm_workers():
    """D2: pre-warm persistent workers so the FIRST pulse is fast, not cold.

    Waits for servers to register (the registry starts empty), then spawns each
    collaborative server's worker and fires one cheap read to load its model.
    Best-effort: on any failure the server is left un-warmed and the lazy path in
    `_worker_for` still handles it on demand. Disable with GM_PREWARM=0."""
    if os.environ.get("GM_PREWARM", "1" if _cfg["prewarm"] else "0") == "0":
        return
    # Warming is the daemon's job when there is one: a gateway that pre-warms
    # spawns exactly the local worker set the shared model exists to avoid, and
    # it would do it eagerly at startup, before any tool call could delegate.
    if _daemon_reachable():
        return
    while True:
        # Re-probe EVERY sweep, and bypass the backoff in _daemon_reachable():
        # that backoff exists so a missing daemon isn't probed per tool call,
        # but here it is the bug. Two clients starting in the same second both
        # find no daemon, both set the 30 s backoff; the one that loses the
        # election then pre-warms a full local set inside its own blind window
        # — and those workers hold the graph files for the rest of the process.
        # Measured: two Claude Desktop surfaces 1 s apart, two worker sets, one
        # of them permanently degraded to sqlite3. A 0.4 s probe every 2 s at
        # startup is cheaper than a duplicate 1.1 GB model and a second writer.
        if not _IS_DAEMON and gm_answers(GRAY_MATTER_HOST, resolve_port()):
            _shutdown_workers()          # dismiss anything this sweep spawned
            _prewarmed.clear()
            return
        for s in _registry.alive_servers():
            if s.name in _prewarmed or not s.collaborative:
                continue
            _prewarmed.add(s.name)                     # mark first: don't hammer on repeated failure
            tool, args = _WARM_TOOL.get(s.name, (None, None))
            try:
                if tool is None:
                    _worker_for(s.name)                # unknown server: at least pay the import now
                else:
                    await _call_server_async(s.name, tool, args)
            except Exception:  # noqa: BLE001
                _prewarmed.discard(s.name)             # let a later sweep (or lazy path) retry
        await asyncio.sleep(2)


def _worker_for(server_name: str):
    pkg = {"neurag": "neurag.server", "neuron": "neuron.server"}.get(server_name, server_name + ".server")
    p = _workers.get(server_name)
    if p is None or p.poll() is not None:        # not started, or died -> (re)spawn
        # Windows: suppress the console window for the worker (a piped child would
        # otherwise pop a visible CMD). GM's daemon already does this; the worker
        # didn't — harmless before, but the startup self-bootstrap now spawns it
        # eagerly, so the window showed at launch.
        creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        p = subprocess.Popen(
            [sys.executable, "-m", "gray_matter._worker", pkg],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1,
            creationflags=creationflags,
        )
        _workers[server_name] = p
        # A fresh worker is alive. mark_dead() is never undone for a managed
        # server (no heartbeat), so _reap_dead_workers killed every respawn
        # within 10 s, mid-call: "worker gave no response" on each pre_turn
        # that loads the model (seen live 2026-11-27, status read dead pid=0).
        _registry.heartbeat(server_name)
    return p


def _reap_worker(p: "subprocess.Popen") -> None:
    """kill() alone is not enough: without wait() the child lingers as a
    zombie (POSIX) / leaked handles, and its PIPE buffers stay open."""
    try:
        p.kill()
    except Exception:  # noqa: BLE001
        pass
    try:
        p.wait(timeout=3)
    except Exception:  # noqa: BLE001
        pass
    for fh in (getattr(p, "stdin", None), getattr(p, "stdout", None),
               getattr(p, "stderr", None)):
        try:
            if fh is not None:
                fh.close()
        except Exception:  # noqa: BLE001
            pass


def _shutdown_workers() -> None:
    """Flush sincrono dei worker prima di morire (checkpoint finale).

    Su Windows non esistono segnali: Popen.terminate() è TerminateProcess, che
    uccide senza dare al worker la possibilità di salvare. Il worker risponde a
    {"op": "shutdown"} facendo save_all() e uscendo; solo se non esce nel
    timeout lo si termina a forza (l'ultimo checkpoint periodico copre il resto).
    """
    for name, p in list(_workers.items()):
        try:
            p.stdin.write(json.dumps({"op": "shutdown"}) + "\n")
            p.stdin.flush()
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.terminate()
                try:
                    p.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    p.kill()
        except (BrokenPipeError, OSError):
            pass
        _workers.pop(name, None)


def _reap_orphans() -> None:
    """Single-instance: termina i processi della suite rimasti orfani.

    Quando il client muore, il gateway e i suoi worker restano vivi (process
    group staccato) e scrivono sullo stesso DB. All'avvio di un'istanza nuova
    si chiudono subito, l'ultima istanza vince. Nota: il python.exe del venv
    e' il redirector CPython — Popen vede lo stub, il vero interprete e' suo
    figlio. Uccidere lo stub non uccide il figlio: si itera finche' il
    registro pids non e' pulito (la morte si propaga per un paio di giri).
    """
    try:
        from gray_matter import pids as _pids
        for _ in range(3):
            orph = _pids.orphans()
            if not orph:
                return
            for o in orph:
                try:
                    if _pids.alive(o["pid"]):
                        subprocess.run(
                            ["taskkill", "/PID", str(o["pid"]), "/F"],
                            capture_output=True, timeout=10,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                        )
                    _pids.forget(o["pid"])
                except Exception:  # noqa: BLE001 — best-effort, mai bloccare
                    pass
            time.sleep(0.3)
    except Exception:  # noqa: BLE001
        pass


# --- Shared worker set ------------------------------------------------------
# The workers hold the embedding models (~1.1 GB for the pair) AND the write
# handle on the graph store. One set PER GATEWAY meant every open AI client paid
# the gigabyte again and, worse, put another writer on the same DB — the clobber
# risk pids.orphans() already warns about. So: the daemon owns the workers, and
# a stdio gateway asks it over IPC. If no daemon answers, the gateway spawns its
# own set exactly as before — the fallback is the old code path, untouched.
_IS_DAEMON = False
_daemon_gone_until = 0.0        # backoff so a missing daemon isn't probed per call


def _daemon_reachable() -> bool:
    global _daemon_gone_until
    if _IS_DAEMON or os.environ.get("GM_SHARED_WORKERS", "1") == "0":
        return False
    if time.time() < _daemon_gone_until:
        return False
    if gm_answers(GRAY_MATTER_HOST, resolve_port()):
        return True
    _daemon_gone_until = time.time() + 30
    return False


async def _via_daemon(payload: dict, timeout: float = 60.0):
    """Send one IPC request to the daemon; None means 'no daemon, do it yourself'.

    Blocking socket work goes to the executor: this runs inside the stdio
    server's event loop and a 60 s tool call would otherwise freeze the client.
    """
    if not _daemon_reachable():
        return None
    global _daemon_gone_until
    loop = asyncio.get_running_loop()
    try:
        resp = await loop.run_in_executor(None, lambda: _send_ipc(payload, timeout))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(resp, dict) or "error" in resp:
        # A refused connection means the daemon died mid-flight -> fall back and
        # stop probing for a bit. An "unauthorized" is NOT transient: still fall
        # back, but it is worth seeing in the log rather than silently degrading.
        err = (resp or {}).get("error", "")
        if err == "unauthorized":
            print("gray-matter: IPC token rejected — running workers locally",
                  file=sys.stderr)
        _daemon_gone_until = time.time() + 30
        return None
    return resp.get("result")


async def _call_server_async(server_name: str, tool_name: str, arguments: dict,
                             user: bool = False) -> str:
    """Call a server tool via its persistent worker (imported once, model kept warm).

    Prefers the daemon's shared worker; spawns a local one only if there is none.
    ``user``: the request is the user's own (CLI/GUI through `gm-neurag`), never
    an MCP caller's — only the daemon sets it, and it travels outside the args.
    """
    pin = False
    if isinstance(arguments, dict) and "_scope_pin" in arguments:
        arguments = dict(arguments)
        pin = bool(arguments.pop("_scope_pin"))
    shared = None if user else await _via_daemon(
        {"action": "call", "server": server_name, "tool": tool_name, "args": arguments,
         **({"pin": True} if pin else {})},
        timeout=IPC_TOOL_TIMEOUT)
    if shared is not None:
        return shared
    lock = _worker_locks.setdefault(server_name, asyncio.Lock())
    async with lock:                              # one request at a time per pipe
        p = _worker_for(server_name)
        # get_running_loop, not get_event_loop: all three call sites are inside
        # coroutines, and get_event_loop() is deprecated when a loop is already
        # running (3.12+) — on 3.14 the no-loop case raises outright.
        loop = asyncio.get_running_loop()

        def _io() -> str:
            p.stdin.write(json.dumps({"tool": tool_name, "args": arguments,
                                      **({"user": True} if user else {})}) + "\n")
            p.stdin.flush()
            return p.stdout.readline()

        try:
            # First Neuron call loads fastembed -> allow headroom.
            resp_line = await asyncio.wait_for(loop.run_in_executor(None, _io), timeout=60)
        except Exception as e:  # noqa: BLE001 — timeout or pipe error: drop the worker
            _reap_worker(p)
            _workers.pop(server_name, None)
            _registry.mark_dead(server_name)
            return f"[{server_name}] error: {e}"

    if not resp_line:
        _registry.mark_dead(server_name)
        return f"[{server_name}] error: worker gave no response"
    try:
        resp = json.loads(resp_line)
    except Exception:
        return f"[{server_name}] error: bad worker response"
    if not resp.get("ok"):
        # ponytail: trace nel messaggio — L2 è intermittente, quando ricapita
        # vogliamo il traceback intero, non solo str(e)
        tail = f"\n{resp['trace']}" if resp.get("trace") else ""
        return f"[{server_name}] error: {resp.get('error')}{tail}"
    # Cronometro per server: il worker misura l'esecuzione del tool (modello
    # già caldo, senza pipe/proxy) — è il numero che dice DOVE va il tempo.
    if resp.get("ms") is not None:
        lat = _worker_lat.setdefault(server_name, {"calls": 0, "ms_total": 0.0, "last_ms": 0.0})
        lat["calls"] += 1
        lat["ms_total"] += float(resp["ms"])
        lat["last_ms"] = float(resp["ms"])
    return resp["text"]


async def _fetch_tool_schemas(server_name: str) -> dict:
    """F12: ask a server's worker for its real tool list (name -> {description,
    inputSchema}) so GM can re-publish accurate pass-through schemas. Best-effort:
    returns {} on any failure (caller falls back to an empty schema)."""
    shared = await _via_daemon({"action": "schemas", "server": server_name},
                               timeout=IPC_TOOL_TIMEOUT)
    if shared is not None:
        return shared
    lock = _worker_locks.setdefault(server_name, asyncio.Lock())
    async with lock:
        p = _worker_for(server_name)
        loop = asyncio.get_running_loop()

        def _io() -> str:
            p.stdin.write(json.dumps({"op": "list_tools"}) + "\n")
            p.stdin.flush()
            return p.stdout.readline()

        try:
            resp_line = await asyncio.wait_for(loop.run_in_executor(None, _io), timeout=60)
        except Exception:  # noqa: BLE001 — pipe/timeout: leave schemas unknown
            return {}
    try:
        resp = json.loads(resp_line)
    except Exception:  # noqa: BLE001
        return {}
    if not resp.get("ok"):
        return {}
    return {
        t["name"]: {"description": t.get("description") or "",
                    "inputSchema": t.get("inputSchema") or {"type": "object", "properties": {}}}
        for t in resp.get("tools", []) if t.get("name")
    }


async def _ensure_schemas(server) -> None:
    """Populate a server's real tool schemas once (cached on the ServerEntry)."""
    if server.tool_schemas:
        return
    schemas = await _fetch_tool_schemas(server.name)
    if schemas:
        server.tool_schemas = schemas


_SUBSERVER_MODULES = {"neuron": "neuron.server", "neurag": "neurag.server"}


def detect_subservers() -> list[str]:
    """Installed sub-servers importable right now (gateway self-discovery).

    Un tool andato standalone (`<tool> go-standalone` / `gray-matter deregister
    --tool ...`) è escluso anche se importabile: ha la sua entry MCP diretta nei
    client — ri-gestirlo qui duplicherebbe i suoi tool."""
    import importlib.util
    try:
        from gray_matter.clients import unmanaged_tools
        skip = unmanaged_tools()
    except Exception:  # noqa: BLE001 — mai bloccare il bootstrap
        skip = set()
    out = []
    for name, mod in _SUBSERVER_MODULES.items():
        if name in skip:
            continue
        try:
            if importlib.util.find_spec(mod) is not None:
                out.append(name)
        except Exception:  # noqa: BLE001 — broken/partial install
            pass
    return out


async def _bootstrap_subservers() -> None:
    """Gateway model: the client launches only GM, so the sub-servers no longer
    auto-register via IPC. GM self-discovers the installed ones, fetches their real
    tools from the worker (F12) and registers them as MANAGED so `list_tools`
    re-publishes them. Best-effort; a sub-server that fails to answer is skipped
    (a later autoregister or a retry can still add it)."""
    for name in detect_subservers():
        if _registry.get_server(name):
            continue
        schemas = await _fetch_tool_schemas(name)
        if schemas:
            _registry.register_managed(name, list(schemas), schemas)


async def _sleep_monitor():
    """Background: if idle > IDLE_SLEEP_TIMEOUT, flag sleep.

    Sleep means servers are marked 'sleeping'. First client call wakes them.
    """
    global _is_sleeping
    while True:
        await asyncio.sleep(30)
        # Daily backup of the three stores (backup.py): a no-op once today's
        # folder exists, so this costs one exists() per tick. Daemon only —
        # every stdio gateway runs this monitor too, and four processes racing
        # for the same .tmp folder at midnight is not a backup. Off the loop
        # thread: a copy of a few MB must not stall the IPC listener.
        if _IS_DAEMON:
            try:
                from gray_matter import backup as _backup
                folder, errors = await asyncio.to_thread(_backup.run)
                for e in errors:
                    print(f"[gray-matter] backup: {e}", file=sys.stderr)
                if folder:
                    print(f"[gray-matter] backup: {folder}", file=sys.stderr)
            except Exception as exc:  # noqa: BLE001 — say it, never crash the monitor
                print(f"[gray-matter] backup skipped: {exc}", file=sys.stderr)
        now = time.time()
        idle = now - _last_call_time

        if idle > IDLE_SLEEP_TIMEOUT and not _is_sleeping:
            _is_sleeping = True
            for s in _registry.all_servers():
                s.status = "sleeping"
            # Idle maintenance: let unused bridges (unconfirmed hypotheses) decay.
            # Daemon only, like the backup above: every stdio gateway runs this
            # monitor with its OWN idle clock, so the decay ran once per open
            # client and its speed depended on how many were open (ADR-010 F0).
            # The daemon sees every gateway's calls: its idle is the real one.
            if _IS_DAEMON:
                try:
                    from gray_matter.bridges import decay
                    decay()
                except Exception:  # noqa: BLE001
                    pass
        elif idle < IDLE_SLEEP_TIMEOUT and _is_sleeping:
            _is_sleeping = False
            # Wake the servers too: only the flag woke, so `gray-matter status`
            # read "sleeping" for the rest of the daemon's life while its
            # workers answered every call (seen 2026-11-24).
            for s in _registry.all_servers():
                if s.status == "sleeping":
                    s.status = "alive"


async def _reap_dead_workers():
    """A server marked dead means its CLIENT stopped heart-beating. We must NOT
    kill that pid — in the additive model it's the client's own process, not
    ours (the old code SIGTERM'd it, a real bug). What Gray-Matter actually owns
    is the persistent worker subprocess; drop it so the next call to that server
    respawns a fresh worker via `_worker_for`."""
    while True:
        await asyncio.sleep(HEARTBEAT_INTERVAL * 2)
        for server in _registry.all_servers():
            if server.status != "dead":
                continue
            p = _workers.pop(server.name, None)
            if p is not None:
                _reap_worker(p)


def _build_stats() -> dict:
    """Live observability counters — the orchestrator's tachometer."""
    from gray_matter.bridges import all_bridges
    hits, misses = _stats["cache_hits"], _stats["cache_misses"]
    total = hits + misses
    return {
        "pulses": int(_stats["pulses"]),
        "cache_hits": int(hits),
        "cache_misses": int(misses),
        "cache_hit_rate": round(hits / total, 3) if total else 0.0,
        "cache_size": _ctx_cache.size(),
        "flashes": int(_stats["flashes"]),
        "bridges_added_session": int(_stats["bridges_added"]),
        "bridges_total": len(all_bridges()),
        # no kb_hints here: pointers are minted in each stdio gateway, not in
        # the daemon — the knowledge_neighbors count below is the gate's lookups
        "tool_calls": dict(sorted(_tool_calls.items(), key=lambda kv: -kv[1])),
        "avg_miss_ms": round(_stats["pulse_ms_total"] / misses, 1) if misses else 0.0,
        "workers_alive": [n for n, p in _workers.items() if p.poll() is None],
        "worker_latency": {n: {"calls": v["calls"],
                               "avg_ms": round(v["ms_total"] / v["calls"], 1) if v["calls"] else 0.0,
                               "last_ms": v["last_ms"]}
                           for n, v in _worker_lat.items()},
    }


async def _build_doctor() -> dict:
    """Health snapshot: servers, workers, cache, bridges (+ vector tier NeuRAG)."""
    from gray_matter.bridges import all_bridges
    servers = [{
        "name": s.name, "status": s.status, "alive": s.is_alive(),
        "collaborative": s.collaborative,
        "worker": s.name in _workers and _workers[s.name].poll() is None,
    } for s in _registry.all_servers()]
    out = {
        "version": __version__,
        "sleeping": _is_sleeping,
        "servers": servers,
        "cache_size": _ctx_cache.size(),
        "bridges_total": len(all_bridges()),
    }
    # Degradato mai silenzioso (nota del 2026-07-20): se NeuRAG gira sul
    # tier sqlite3 (niente pyturso → coseno in Python), il doctor deve dirlo.
    neurag = _registry.get_server("neurag")
    if neurag and neurag.is_alive():
        try:
            import json as _json
            raw = await _call_server_async("neurag", "knowledge_status", {})
            out["neurag_engine"] = _json.loads(raw).get("engine", "?")
        except Exception:  # noqa: BLE001 — best-effort, il doctor non deve rompersi
            pass
    # Doctor esteso (passo 5): tier di TUTTI e 3 + se il cross-store è attivo.
    # Env reale > .env GM (stessa precedenza del runtime); best-effort sempre.
    try:
        from gray_matter import bridges as _b, cloud as _cloud
        saved = _cloud.read_env_file(_cloud.default_env_file())

        def _has(key: str) -> bool:
            return bool(os.environ.get(key, "").strip() or saved.get(key))

        shared = _has("TURSO_AUTH_TOKEN")
        out["tiers"] = {
            "neuron": "Turso (cloud)" if _has("TURSO_DATABASE_URL") and shared
                      else "local",
            "neurag": out.get("neurag_engine")
                      or ("Turso (cloud)" if _has("NEURAG_TURSO_DATABASE_URL")
                          and (shared or _has("NEURAG_TURSO_AUTH_TOKEN")) else "local"),
            # Il motore vero, non un'etichetta: "SQLite (local)" scritto a mano
            # lo diceva anche con bridges.py su Turso locale.
            "gm_bridges": _b.ENGINE_NAME,
        }
    except Exception:  # noqa: BLE001
        pass

    def _collab(name: str) -> bool:
        s = _registry.get_server(name)
        return bool(s and s.is_alive() and s.collaborative)

    # Cross-store = i bridge possono lavorare: entrambi gli store vivi e nel
    # pulse combinato (uno isolato/spento = niente collegamenti, per design).
    out["cross_store"] = _collab("neuron") and _collab("neurag")
    return out


def _norm(s: str) -> str:
    return " ".join(s.lower().split())


_HOOK_SEEN: dict = {}            # session -> (kb pointers shown, fact ids shown: recalled or flashed)
# ADR-021 use-bonus experiment, per TURN since 2026-11-24 (per session gave 4
# sessions against 7 after a week): the arm drawn for a session's latest recall,
# read back when its Stop hook reports which facts the turn used.
_TURN_ARM: dict = {}


def _log_use(session: str, args: dict) -> None:
    """One line per turn into logs/use_experiment.jsonl: the arm of the turn's
    recall, the facts it showed and those the turn used (memhook.used_facts,
    the distinctive-word measure). Its own log, not the transcripts: those of
    08-20/11 were lost. Best-effort: a write error never fails the confirm."""
    a = _TURN_ARM.pop(session, None)
    if a is None or not isinstance(args, dict):
        return
    try:
        from gray_matter.paths import logs_dir
        p = logs_dir() / "use_experiment.jsonl"
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"t": round(time.time()), "arm": a,
                                 "shown": list(args.get("shown") or []),
                                 "used": list(args.get("facts") or [])}) + "\n")
    except OSError:
        pass
# The save check for hosts with no readable transcript (Kimi, Codex, OpenCode):
# every store_turn of every client passes through the daemon, so it can tell
# whether a fact landed since this session's message arrived. shortcut: one
# clock for all sessions, so another client's save hides a missed one; key it
# by session if the hosts ever pass their session id to the MCP call.
_HOOK_TURN: dict = {}            # session -> time its last message was recalled
_FACT_AT = [0.0]                 # time of the last store_turn that carried a fact


def _saved_since(session: str) -> str:
    """'yes' / 'no' for the session's current turn, 'unknown' when the daemon
    never saw its message (restarted, or no recall hook)."""
    t = _HOOK_TURN.get(session)
    if t is None:
        return "unknown"
    return "yes" if _FACT_AT[0] >= t else "no"
_FACT_ID = re.compile(r"#([0-9a-f]{8})\b")


def _note_facts(text: str, seen: set) -> None:
    """ADR-015 D7: remember the fact ids a pre_turn showed, so neither the next
    pre_turn nor a flash brings them back in the same session."""
    seen.update(_FACT_ID.findall(text or ""))
_PROFILE_SENT = False            # this gateway process already served the user/habit facts


def _client_has_memhook() -> bool:
    """The client is Claude Code with our memory hook wired: the hook brings
    the profile on the session's first message, so the gateway must not bring
    it a second time (seen live, 2026-11-08). Any doubt: False."""
    try:
        client = app.request_context.session.client_params.clientInfo.name or ""
        if "claude-code" not in client.lower():
            return False
        settings = os.path.join(os.path.expanduser("~"), ".claude", "settings.json")
        with open(settings, encoding="utf-8-sig") as fh:
            return "gm_memhook" in fh.read()
    except Exception:  # noqa: BLE001 — no request context, no file: assume no hook
        return False
_HOOK_SESSIONS_MAX = 50          # ponytail: clear-all when full; LRU if sessions ever overlap that much
# ponytail: threshold tuned on 5 real messages (2026-11-05): the 2 useful ones
# scored 0.55, the 2 wrong ones 0.45-0.46. Redo it on the log once there are more turns.
KB_VECTOR_MIN_COS = 0.55
_KB_HITS =re.compile(r"\[\d+\]\s+(.+?)\s+\(cos ([0-9.]+)\)")


def _inside(src: str, folder: str) -> bool:
    """A KB source path lies in `folder` (the client's working directory)."""
    try:
        s = os.path.normcase(os.path.abspath(src.partition(" :: ")[0].strip()))
        f = os.path.normcase(os.path.abspath(folder))
    except (TypeError, ValueError):
        return False
    return s == f or s.startswith(f.rstrip("\\/") + os.sep)


async def _kb_vector_pointer(text: str, shown: set, cwd: str = "") -> str:
    """One line pointing at the KB SECTION closest in meaning to the message.

    Vector, not the name/trigger lookup of _knowledge_hint. Measured on five real
    messages: the SQL lookup named a whole folder every time ("audit", "docs",
    "gray_matter") — and minted the noise bridges flash<->audit, flusso<->docs —
    while the vector search named the right section twice, both at cos 0.55.
    It mints NO bridge: a pointer is a hint, a bridge is a claim.

    `cwd`: the client's working directory. A document inside it is already on
    disk where the model works: in this repo the pointer was followed 0 times in
    17 (2026-11-23), while on project documents kept elsewhere it was right 10
    times in 11. So the first hit OUTSIDE `cwd` is the pointer, same threshold."""
    neurag = _registry.get_server("neurag")
    if not (neurag and neurag.is_alive() and neurag.collaborative) or PROACTIVE_BUDGET <= 0:
        return ""
    try:
        kq = await _call_server_async("neurag", "knowledge_query",
                                      {"query": text, "top_n": 3 if cwd else 1})
    except Exception:  # noqa: BLE001 — a pointer is best-effort, never blocks the recall
        return ""
    m = next((h for h in _KB_HITS.finditer(kq or "") if not (cwd and _inside(h.group(1), cwd))), None)
    if not m or float(m.group(2)) < KB_VECTOR_MIN_COS:
        return ""
    src, _, section = m.group(1).partition(" :: ")
    where = os.path.basename(src.strip())
    # drop "(11/15)", the chunk index, also when the date follows it: "(2/5) [2026-11-22]"
    section = re.sub(r"\s*\(\d+/\d+\)(?=(\s*\[[^\]]*\])?$)", "", section.strip())
    # The last heading only, capped: a five-level breadcrumb cost ~70 tokens per message.
    section = section.split(" > ")[-1][:60]
    label = f"{where} :: {section}" if section else where
    if label in shown:
        return ""
    shown.add(label)
    return f'\n\n📚 KB: "{label}" (cos {m.group(2)}) → knowledge_query for the detail'


_HEADER = re.compile(r"^\[neuron\] (ctx=\S+).*$")
# Graph metadata riding on the cache line: "links:a-[s]->b|..." and "nodes:x(0),...".
# The cache line too ("cache: a(↑) | b(·)"): without it a fresh model acted
# the same on 7 failure scenarios (14/14, A/B 2026-11-18), ~56 chars a message.
_META_SEGMENT = re.compile(r"^(links:|nodes:|\(vector fallback\)$|cache: |[^\[|]*\([↑·]\)$)")


def _trim_for_hook(ctx: str) -> str:
    """What the HOOK injects of a pre_turn answer: the facts, not the tool's chrome.

    Measured on 91 real recalls (ledger, 2026-11-10): ~22% was text repeated on
    every turn, which the model never acted on:
      - the `→` lines: "then store_turn" (the save check of every client hook
        does that now) and "useful? confirm(...)" (explicit use: 1%);
      - the stats in the header (turn, nodes, links, db): `ctx=` stays, it
        names the context a `switch_context` would leave;
      - graph metadata segments (links:, nodes:), often cut mid-word by the budget;
      - "no relevant context" notes: nothing to act on.
    The pre_turn TOOL answer is untouched: an MCP-only client still gets it all."""
    out = []
    for line in ctx.splitlines():
        s = line.strip()
        if s.startswith("→ ") or s.startswith("⚠ no relevant context"):
            continue
        m = _HEADER.match(s)
        if m:
            line = f"[neuron] {m.group(1)}"
        elif " | " in line or s.startswith(("links:", "nodes:", "cache: ")):
            keep = [seg for seg in line.split(" | ") if not _META_SEGMENT.match(seg.strip())]
            if not keep:
                continue
            line = " | ".join(keep)
        out.append(line)
    return "\n".join(out).strip("\n")


def _project_scope(cwd: str) -> str:
    """The Neuron context of a session at `cwd`: its project's, the inbox when it
    has none, "" without projects.json (keep the shared one)."""
    try:
        from gray_matter.projects import session_context
        return session_context(cwd)
    except Exception:  # noqa: BLE001 — a bad projects.json must never break a recall
        return ""


# This stdio gateway's session context: None until its first Neuron call, then
# the project of the folder the client started it in ("" = none). A gateway
# lives as long as its client's session, so this is per session.
_SESSION_CTX: "list[str | None]" = [None]
_SESSION_PINNED = [False]       # set by switch_context: then the gateway's choice wins

# Daemon side: the project of the newest message the memory hook saw (its cwd,
# read per message). A gateway's own choice is made once per process, and the
# Claude Desktop app shares ONE gateway among its sessions: live 2026-11-27 a
# GM session's store_turn went to `qwen`, another session's folder, while the
# hook of the same message said graymatter. So the daemon gives a gateway's
# Neuron call the hook's project, unless that gateway pinned one by switching.
# ponytail: newest message wins; two sessions in two projects typing at the
# same moment can swap, a per-session key if MCP calls ever carry one.
_LAST_HOOK_SCOPE: "list[str]" = [""]


def _turn_scoped(server: str, args, pinned: bool):
    """A gateway's Neuron call arguments, with the project of the turn (the
    hook's) unless the gateway pinned its own with switch_context."""
    if server != "neuron" or not isinstance(args, dict) or pinned or not _LAST_HOOK_SCOPE[0]:
        return args
    return {**args, "_scope": _LAST_HOOK_SCOPE[0]}


def _root_path(uri: str) -> str:
    """`file:///D:/Desktop/GM` -> `D:/Desktop/GM` ("" for another scheme)."""
    from urllib.parse import unquote, urlparse
    u = urlparse(uri)
    if u.scheme != "file":
        return ""
    path = unquote(u.path)
    return path[1:] if len(path) > 2 and path[0] == "/" and path[2] == ":" else path


async def _resolve_session_ctx() -> None:
    """This gateway's session context, once: from the folder the CLIENT says it
    works in (MCP roots), else this process's own folder. Live 2026-11-27 the
    gateway of a Claude Desktop session did not start in the project folder, and
    the model's facts went to the inbox while the hook (which gets the message's
    cwd) recalled the project."""
    if _SESSION_CTX[0] is not None:
        return
    folder = os.getcwd()
    try:
        sess = app.request_context.session
        caps = sess.client_params.capabilities if sess.client_params else None
        if caps is not None and getattr(caps, "roots", None) is not None:
            res = await asyncio.wait_for(sess.list_roots(), timeout=3)
            folder = next((p for r in res.roots if (p := _root_path(str(r.uri)))), folder)
    except Exception:  # noqa: BLE001 — no roots: the process folder, as before
        pass
    _SESSION_CTX[0] = _project_scope(folder)


def _session_scoped(name: str, arguments: dict) -> dict:
    """Neuron call arguments with the session's `_scope`. In a project session
    `switch_context` moves THIS session only: the shared pointer is for the
    sessions that have no project."""
    if _SESSION_CTX[0] is None:
        _SESSION_CTX[0] = _project_scope(os.getcwd())
    if name == "switch_context":
        want = str(arguments.get("context") or "").lower().strip("/")
        if _SESSION_CTX[0]:
            _SESSION_CTX[0] = want or _SESSION_CTX[0]
        _SESSION_PINNED[0] = bool(want)
    out = {**arguments, "_scope": _SESSION_CTX[0]} if _SESSION_CTX[0] else dict(arguments)
    if _SESSION_PINNED[0]:
        out["_scope_pin"] = True
    return out


async def _hook_recall(prompt: str, session: str, profile: "bool | None" = None,
                       exclude: "list | None" = None, cwd: str = "") -> str:
    """ADR-014: what the UserPromptSubmit hook injects, composed in ONE IPC call.

    Context, KB pointer, plus the flash. The KB search needs only
    the message, so it starts FIRST and overlaps everything else (it is the slow
    piece, ~320 ms; NeuRAG and Neuron have separate locks). The hook process
    stays a courier: start, one request, print."""
    if session not in _HOOK_SEEN and len(_HOOK_SEEN) >= _HOOK_SESSIONS_MAX:
        _HOOK_SEEN.clear()
        _TURN_ARM.clear()
    # The hook reads both from the transcript (memhook.session_memory); an older
    # hook sends neither, and the daemon's own per-session record stands in.
    first = (session not in _HOOK_SEEN) if profile is None else bool(profile)
    _HOOK_TURN[session] = time.time()
    shown, flashed = _HOOK_SEEN.setdefault(session, (set(), set()))
    flashed.update(str(i) for i in (exclude or []))
    q = " ".join(prompt.split())[:300]
    kb_task = asyncio.ensure_future(_kb_vector_pointer(q, shown, cwd))
    # The whole message is the topic, no extracted keywords: pre_turn searches
    # each keyword as its own key, and extract (a closed stopword list) handed
    # it `ciao`, `visto`, `dovremmo` — each one taking a context slot. Measured
    # 2026-11-06: extracted topic -> wasapi/endpoint-audio, message -> release/
    # installer/daemon. ponytail: no keywords at all; graph-filtered ones only
    # if the dry-run log shows recall missing concepts the message names.
    import random
    _TURN_ARM[session] = random.random() < 0.5   # ADR-021, drawn per turn; logged by _log_use
    args = {"topic": q, "profile": first,      # ADR-015 D7.1: user/habit once per session
            "exclude": sorted(flashed),
            "arm": _TURN_ARM[session]}         # ADR-021: inert while NEURON_FACT_USE_BONUS is 0
    scope = _project_scope(cwd)
    if cwd:                                    # a hook that sends no folder (OpenCode's) knows no project:
        _LAST_HOOK_SCOPE[0] = scope            # its "inbox" must not override a gateway that has one
    if scope:
        args["_scope"] = scope                 # the session's project, not the shared pointer
    ctx, (flash, _c), kb = await asyncio.gather(
        _call_server_async("neuron", "pre_turn", args),
        _maybe_flash(args["topic"], flashed, scope),
        kb_task)
    from gray_matter.memhook import BUDGET, PROFILE_BUDGET
    _note_facts(ctx, flashed)
    ctx = _trim_for_hook(ctx or "")
    flash = _unless_shown(flash, ctx)
    # Episodes -> knowledge: bridges matching the message, or the facts just
    # shown (a promoted fact has its `#id <-> node` bridge). Nothing when none.
    links = ""
    if PROACTIVE_BUDGET > 0:
        shown_ids = " ".join(_FACT_ID.findall(ctx or ""))
        links = "".join(f"\n{b}" for b in await _bridge_blocks(f"{q} {shown_ids}", set(), 2))
    extra = kb + links + (f"\n\n{flash}" if flash else "")
    # The hook cuts at memhook.BUDGET from the END: three long facts filled it
    # and the flash and the KB pointer, last, were cut away (live, 2026-11-08).
    # Room for them first, then the memory context gets what is left; the
    # session's first message has the profile's room on top.
    ctx, room = ctx or "", BUDGET + (PROFILE_BUDGET if first else 0) - len(extra)
    if len(ctx) > room:
        ctx = ctx[:max(0, room - 1)].rstrip() + "…"
    return ctx + extra


# One line of Neuron's forgotten(facts=True): `  [kind] text (concept) #id`.
# Neuron picks what may flash; `fact` is a migrated fact (no kind before 6.10).
# user/habit are never accepted here, whatever Neuron sends: they are personal.
_FLASH_LINE = re.compile(r"\[(?P<kind>idea|decision|fix|fact)\] .* \((?P<concept>[^()]*)\) "
                         r"#(?P<id>[0-9a-f]{8})\s*$", re.M)


def _unless_shown(flash: str, shown: str) -> str:
    """The flash, or "" when its fact is already in the recall it travels with.
    Both run in parallel, so the flash cannot exclude what the recall picks: on
    a live probe (2026-11-27) the flash repeated a fact of the same message."""
    m = _FACT_ID.findall(flash or "")
    return "" if m and m[-1] in set(_FACT_ID.findall(shown or "")) else flash


async def _maybe_flash(topic: str, flashed: "set | None" = None, scope: str = ""):
    """Flash v1/v2 — returns (note, concept). `concept` is the dormant keyword
    surfaced (or ""), which pulse uses to auto-persist a cross-store bridge (v3b).
    Fires at a topic shift, mid-band `near` selection, rate-limited by a min gap +
    a per-session per-concept cooldown (`flashed`, like `shown` in _knowledge_hint)."""
    global _last_topic, _calls_since_flash
    flashed = _flashed if flashed is None else flashed
    _calls_since_flash += 1
    shifted = _norm(topic) != _norm(_last_topic)
    _last_topic = topic
    if not shifted or _calls_since_flash < FLASH_MIN_GAP:
        return "", ""

    neuron = _registry.get_server("neuron")
    if not neuron or not neuron.is_alive():
        return "", ""
    # ADR-016 D2: a dormant FACT near the topic, or nothing. It used to be a
    # bare node name, from a band that starts under the model's noise and, when
    # empty, from the oldest node of all: the carbonara got a flash.
    # The session's project, like the recall beside it: without it Neuron read
    # its global active context, and every project got graymatter's flashes.
    args = {"facts": True, "near": topic, "threshold": 5, "top_n": 1, "exclude": sorted(flashed)}
    if scope:
        args["_scope"] = scope
    out = await _call_server_async("neuron", "forgotten", args)
    m = _FLASH_LINE.search(out or "")
    if not m:                                        # "No dormant fact", errors, old Neuron
        return "", ""
    fid = m.group("id")
    if fid in flashed:                               # once per fact per session
        return "", ""
    flashed.add(fid)
    _calls_since_flash = 0
    _stats["flashes"] += 1
    return f"⚡ Flash: {m.group(0).strip()}", m.group("concept")


# ---------------------------------------------------------------------------
# IPC listener (background) — receives registrations, heartbeats
# ---------------------------------------------------------------------------

async def _recv_exact_async(loop, conn, n: int) -> "bytes | None":
    """Read exactly n bytes from a non-blocking socket, or None on short read.

    Suffisso `_async` non decorativo: si chiamava `_recv_exact` come l'omonima
    sincrona di cli.py e la copriva silenziosamente a livello di modulo."""
    buf = b""
    while len(buf) < n:
        try:
            chunk = await loop.sock_recv(conn, n - len(buf))
        except OSError:
            return None
        if not chunk:
            return None
        buf += chunk
    return buf


async def _recv_message(loop, conn) -> bytes:
    """One length-prefixed message: 4-byte big-endian length, then exactly that
    many bytes. Returns the payload (b'' on short read / bad frame). This is the
    fix for the old `data[4:]` single-recv assumption that broke on any message
    split across TCP segments."""
    header = await _recv_exact_async(loop, conn, 4)
    if header is None:
        return b""
    (length,) = struct.unpack("!I", header)
    if length <= 0 or length > 1_000_000:      # sanity guard vs junk/oversize
        return b""
    payload = await _recv_exact_async(loop, conn, length)
    return payload or b""


def _gm_answers_with_startup_grace(host: str, port: int,
                                   tries: int = 6, delay: float = 0.3) -> bool:
    """Repeated gm_answers: tolerates the bind→accept window of a GM starting
    on the same port (singleton race, 2026-08-25).

    Two daemons launched together: A binds but has not reached `listen` yet;
    B's single-shot probe timed out, B concluded "foreign process", moved to
    the next port and overwrote the rendezvous file → TWO live daemons,
    double writer on the graph. A GM answers as soon as it reaches accept; a
    foreign process NEVER answers, so the worst case is tries*delay on a dead
    port."""
    for _ in range(tries):
        if gm_answers(host, port):
            return True
        time.sleep(delay)
    return False


def _quiet_aborted_accept(loop, context: dict) -> None:
    """The `shutdown` action closes the listening socket while an accept is
    pending, and Windows' proactor reports that aborted accept (WinError 995)
    as "Task exception was never retrieved" with a traceback, on every stop.
    That one case is ours and expected; everything else goes to asyncio's
    default handler."""
    exc = context.get("exception")
    if isinstance(exc, OSError) and getattr(exc, "winerror", None) == 995:
        return
    loop.default_exception_handler(context)


async def _ipc_listener(*, exit_on_busy: bool = True):
    """Background task: listens for incoming IPC connections (registrations, heartbeats).

    exit_on_busy: a daemon that finds :9876 taken is a duplicate and must die
    (SystemExit escapes asyncio). A stdio instance (main) must instead keep
    serving MCP without a listener — its managed workers don't need the port."""
    loop = asyncio.get_running_loop()
    loop.set_exception_handler(_quiet_aborted_accept)
    # Singleton PRESERVATO ma porta DINAMICA: se su una porta candidata risponde
    # GIÀ un GM (probe `ping`), siamo un duplicato e moriamo. Se la porta è presa
    # da un processo ESTRANEO, si scala alla prima libera invece di non partire
    # mai. La porta scelta va nel rendezvous file, così i client la seguono.
    if gm_answers(GRAY_MATTER_HOST, resolve_port()):
        if exit_on_busy:
            raise SystemExit(0)   # un GM è già vivo: duplicato → muori
        return                    # istanza stdio: serve MCP senza listener
    server_sock = None
    chosen = None
    for port in range(GRAY_MATTER_PORT, GRAY_MATTER_PORT + GRAY_MATTER_PORT_SPAN):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if os.name == "nt":
            s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        else:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind((GRAY_MATTER_HOST, port))
        except OSError:
            s.close()
            # occupied: if a GM owns it we are a duplicate (die), else try the
            # next port. With startup grace: the single-shot probe loses the
            # race against a GM that bound an instant earlier (see helper).
            if _gm_answers_with_startup_grace(GRAY_MATTER_HOST, port):
                if exit_on_busy:
                    raise SystemExit(0)
                return
            if not exit_on_busy:
                # stdio mode: non cercare un'altra porta — salta l'ascolto IPC
                return
            continue
        server_sock, chosen = s, port
        break
    if server_sock is None:
        # nessuna porta libera nell'intervallo: non possiamo servire l'IPC
        if exit_on_busy:
            raise SystemExit(1)
        return
    # ADR-012 fase 2: chi fa il bind possiede l'identità dell'IPC. Chiave nuova
    # in RAM e canale per utente PRIMA di pubblicare la porta, così nessun
    # client trova la porta senza poter avere un token. Il segreto su file del
    # vecchio schema non autentica più niente: lo si cancella.
    _ipcauth.drop_legacy_token()
    _ipcauth.new_key()
    _ipcauth.serve(chosen)
    write_port_file(chosen)       # i client leggono qui la porta reale
    if chosen != GRAY_MATTER_PORT:
        print(f"gray-matter: porta preferita {GRAY_MATTER_PORT} occupata → uso {chosen}",
              file=sys.stderr)
    server_sock.listen(5)
    server_sock.setblocking(False)

    async def _handle_ipc_conn(conn) -> None:
        """One connection = one task (2026-08-25).

        Two bugs in the previous serial shape: (1) every request was awaited to
        completion — a long `call` (up to IPC_TOOL_TIMEOUT=60s) queued pings and
        heartbeats for EVERYONE, and the monitor marked servers dead that were
        merely waiting in line; (2) any exception outside
        (json.JSONDecodeError, KeyError) — a TypeError on a runaway field, a
        SQLite error in _build_stats — escaped the while loop, propagated
        through gather and KILLED the daemon. Dispatch can no longer kill the
        listener, and long calls run in parallel instead of blocking everyone
        (serialization stays in _call_server_async's per-server lock)."""
        global _last_call_time
        loop = asyncio.get_running_loop()
        try:
            try:
                conn.setblocking(False)
                data = await _recv_message(loop, conn)
                if not data:
                    return
                msg = json.loads(data.decode("utf-8"))
                action = msg.get("action")
                response = {}

                if action == "ping":
                    # Probe di identità: distingue un GM da un'app estranea
                    # sulla stessa porta (usato dal singleton + rendezvous).
                    # Volutamente SENZA token: il probe deve funzionare prima
                    # che chiunque conosca il segreto, e rivela solo "c'è un GM".
                    response = {"status": "ok", "gm": True}
                elif not _ipcauth.verify_request(str(msg.get("token", ""))):
                    # Ogni altra azione tocca la memoria (`call` esegue tool
                    # arbitrari, `knowledge_cmd` scrive nel vault). Loopback
                    # non è una barriera su una macchina multi-utente: serve un
                    # JWT rilasciato sul canale di QUESTO utente, firmato con la
                    # chiave di QUESTO avvio (ADR-012 fase 2).
                    response = {"error": "unauthorized"}
                elif action == "register":
                    _registry.register(
                        name=msg["name"],
                        tool_names=msg["tool_names"],
                        socket_path=msg["socket_path"],
                        pid=msg["pid"],
                    )
                    response = {"status": "ok", "message": f"Registered {msg['name']}"}
                elif action == "heartbeat":
                    ok = _registry.heartbeat(msg["name"])
                    response = {"status": "ok" if ok else "unknown"}
                elif action == "unregister":
                    _registry.unregister(msg["name"])
                    response = {"status": "ok"}
                elif action == "isolate":
                    ok = _registry.set_collaborative(msg["name"], False)
                    response = {"status": "ok" if ok else "unknown"}
                elif action == "collaborate":
                    ok = _registry.set_collaborative(msg["name"], True)
                    response = {"status": "ok" if ok else "unknown"}
                elif action == "mode":
                    want = msg.get("mode") == "collaborate"
                    for s in _registry.all_servers():
                        s.collaborative = want
                    response = {"status": "ok"}
                elif action == "status":
                    response = _registry.to_dict()
                    # pid is the registering client's (0 for the daemon's own):
                    # the process that answers is the worker, so show its pid.
                    for name, info in response.items():
                        w = _workers.get(name)
                        if w is not None and w.poll() is None:
                            info["pid"] = w.pid
                elif action == "stats":
                    response = _build_stats()
                elif action == "doctor":
                    response = await _build_doctor()
                elif action in ("call", "knowledge_cmd"):
                    # ONE shared worker set per machine: a stdio gateway does
                    # not spawn its own, it asks here. `knowledge_cmd` is the
                    # older NeuRAG-only spelling of the same thing, kept so an
                    # older CLI/GUI in the venv still works.
                    srv = "neurag" if action == "knowledge_cmd" else msg.get("server", "")
                    tool_name = msg.get("tool", "knowledge_status")
                    tool_args = msg.get("args", {})
                    tool_args = _turn_scoped(srv, tool_args, bool(msg.get("pin")))
                    # Every stdio gateway's worker calls land here: this is the
                    # counter `stats` shows, across sessions, until restart.
                    _tool_calls[tool_name] = _tool_calls.get(tool_name, 0) + 1
                    # ...and the daemon's idle clock. Only call_tool (stdio)
                    # moved it, and the daemon has no stdio: it fell asleep 600 s
                    # after start and never woke, so the doctor read "sleeping"
                    # on busy servers and on_sleep work could run once per life.
                    _last_call_time = time.time()
                    try:
                        result = await _call_server_async(srv, tool_name, tool_args)
                        response = {"result": result}
                        if tool_name == "confirm" and msg.get("session"):
                            _log_use(str(msg["session"]), tool_args)
                        if tool_name == "store_turn" and isinstance(tool_args, dict) and (
                                tool_args.get("facts") or str(tool_args.get("episode") or "").strip()):
                            _FACT_AT[0] = time.time()
                    except Exception as e:
                        response = {"error": str(e)}
                elif action == "recall":
                    # ADR-014: the memory hook's one request. Counted like a
                    # call, so stats shows how often the hook did the loop.
                    _tool_calls["hook_recall"] = _tool_calls.get("hook_recall", 0) + 1
                    _last_call_time = time.time()
                    try:
                        response = {"result": await _hook_recall(
                            str(msg.get("prompt") or ""), str(msg.get("session") or ""),
                            msg.get("profile"), msg.get("exclude"), str(msg.get("cwd") or ""))}
                    except Exception as e:
                        response = {"error": str(e)}
                elif action == "turn":
                    # A message the recall hook skipped (ack, command): no save check for it.
                    if not msg.get("worth"):
                        _HOOK_TURN.pop(str(msg.get("session") or ""), None)
                elif action == "saved":
                    # memhook save, for hosts whose transcript it cannot read.
                    response = {"result": _saved_since(str(msg.get("session") or ""))}
                elif action == "schemas":
                    # Same reason: the bootstrap must not spawn a local worker
                    # just to learn the tool list.
                    try:
                        response = {"result": await _fetch_tool_schemas(msg.get("server", ""))}
                    except Exception as e:
                        response = {"error": str(e)}
                elif action == "promote":
                    # CLS (§5.3): memory that proved itself becomes
                    # knowledge. Runs HERE, in the daemon, because it needs
                    # both workers — and because GM must never open someone
                    # else's vault itself (I3, and the single-writer lock).
                    response = await _do_promote(bool(msg.get("apply")))
                elif action == "gm-neuron":
                    tool_name = msg.get("tool")
                    tool_args = msg.get("args", {})
                    if not tool_name:
                        response = {"error": "Missing 'tool' parameter"}
                    else:
                        try:
                            result = await _call_server_async("neuron", tool_name, tool_args)
                            response = {"result": result}
                        except Exception as e:
                            response = {"error": str(e)}
                elif action == "gm-neurag":
                    tool_name = msg.get("tool")
                    tool_args = msg.get("args", {})
                    if not tool_name:
                        response = {"error": "Missing 'tool' parameter"}
                    else:
                        try:
                            # Authenticated IPC from the user's CLI/GUI: their
                            # own command, not the AI's (see neurag.ingest).
                            result = await _call_server_async("neurag", tool_name, tool_args,
                                                              user=True)
                            response = {"result": result}
                        except Exception as e:
                            response = {"error": str(e)}
                elif action == "shutdown":
                    response = {"status": "ok"}
                    # Graceful shutdown. On a non-blocking socket use the loop's
                    # sendall: the plain sync sendall could raise
                    # BlockingIOError and choke on the goodbye.
                    resp = json.dumps(response).encode("utf-8")
                    await loop.sock_sendall(conn, struct.pack("!I", len(resp)) + resp)
                    conn.close()
                    server_sock.close()
                    # os._exit skips atexit AND the cleanup at the end of
                    # _run(), so the workers this daemon owns outlived it:
                    # orphan writers on the same graph files, with no final
                    # checkpoint. That is the accumulation pids.py was
                    # written to mop up — better not to create it.
                    # Same for a backup in flight: os._exit would cut the copy
                    # in half. Wait for it (bounded: a wedged disk must not
                    # make `stop` hang forever; the .tmp is swept next run).
                    from gray_matter import backup as _backup
                    if not await asyncio.to_thread(_backup.wait_idle, 120.0):
                        print("[gray-matter] shutdown: backup still running after 120s, "
                              "leaving its .tmp behind", file=sys.stderr)
                    _shutdown_workers()
                    os._exit(0)
                else:
                    response = {"error": f"Unknown action: {action}"}

                resp = json.dumps(response).encode("utf-8")
                await loop.sock_sendall(conn, struct.pack("!I", len(resp)) + resp)
            except (json.JSONDecodeError, KeyError):
                return          # malformed request: no reply is possible
            except Exception as e:  # noqa: BLE001 — the daemon must not die for one request
                try:
                    resp = json.dumps({"error": f"internal error: {e!r}"}).encode("utf-8")
                    await loop.sock_sendall(conn, struct.pack("!I", len(resp)) + resp)
                except OSError:
                    pass
        except OSError:
            pass
        finally:
            try:
                conn.close()
            except OSError:
                pass

    while True:
        try:
            conn, addr = await loop.sock_accept(server_sock)
            asyncio.create_task(_handle_ipc_conn(conn))
        except OSError:
            await asyncio.sleep(0.1)


# ---------------------------------------------------------------------------
# Heartbeat monitor (background) — marks dead servers
# ---------------------------------------------------------------------------

async def _heartbeat_monitor():
    """Background task: check heartbeats, mark dead servers."""
    while True:
        await asyncio.sleep(HEARTBEAT_INTERVAL)
        now = time.time()
        for server in _registry.all_servers():
            if server.managed:
                continue   # worker-backed: liveness is the process, not a heartbeat
            if server.status == "alive" and (now - server.last_heartbeat) > HEARTBEAT_TIMEOUT:
                server.status = "dead"

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def _init_options() -> InitializationOptions:
    """Handshake metadata for stdio mode. `capabilities` is a REQUIRED pydantic
    field — omitting it (as the old inline construction did) raises at the very
    first stdio startup, which daemon-only runs never exercised."""
    from mcp.server.lowlevel import NotificationOptions
    return InitializationOptions(
        server_name="gray-matter",
        server_version=__version__,
        capabilities=app.get_capabilities(
            notification_options=NotificationOptions(),
            experimental_capabilities={},
        ),
        instructions=GM_INSTRUCTIONS,
    )


def _ensure_daemon(wait: float = 5.0) -> bool:
    """Make sure the machine-wide worker owner exists; True if we can delegate.

    Without this the FIRST client still runs its own workers and only the second
    one would share — i.e. the common single-client case would keep paying the
    gigabyte and nothing would ever be shared.

    `wait` is a budget against the MCP handshake, which is blocked while we sit
    here: measured cold start to first `ping` is ~2 s (run_daemon opens the
    listener concurrently with `_bootstrap_subservers`, so the slow model load
    is NOT on this path). 5 s leaves headroom without risking a client-side
    timeout. Best-effort throughout: if it does not come up we run local
    workers, exactly as before.
    """
    if os.environ.get("GM_SHARED_WORKERS", "1") == "0":
        return False
    if gm_answers(GRAY_MATTER_HOST, resolve_port()):
        return True
    try:
        _spawn_gray_matter()
    except Exception:  # noqa: BLE001 — never block the MCP handshake
        return False
    deadline = time.time() + wait
    while time.time() < deadline:
        if gm_answers(GRAY_MATTER_HOST, resolve_port()):
            return True
        time.sleep(0.3)
    return False


def main() -> None:
    """Run Gray-Matter as a stdio MCP server with background IPC listener."""
    _record_self("stdio")
    _reap_orphans()
    # Before any worker can be spawned locally: one shared set per machine.
    if _ensure_daemon():
        global _daemon_gone_until
        _daemon_gone_until = 0.0
    async def _run():
        # Start background tasks
        ipc_task = asyncio.create_task(_ipc_listener(exit_on_busy=False))
        hb_task = asyncio.create_task(_heartbeat_monitor())
        sleep_task = asyncio.create_task(_sleep_monitor())
        reap_task = asyncio.create_task(_reap_dead_workers())
        prewarm_task = asyncio.create_task(_prewarm_workers())

        # Gateway model: self-discover installed sub-servers as managed workers
        # (they no longer autoregister when the client launches only GM).
        await _bootstrap_subservers()

        # Start stdio MCP server
        from mcp.server.stdio import stdio_server
        async with stdio_server() as (read_stream, write_stream):
            await app.run(
                read_stream,
                write_stream,
                _init_options(),
            )

        # Cleanup
        ipc_task.cancel()
        hb_task.cancel()
        sleep_task.cancel()
        reap_task.cancel()
        prewarm_task.cancel()
        _shutdown_workers()

    asyncio.run(_run())

def auto_register_and_run(name: str, tool_names: list[str]) -> None:
    """Called by a server (Neuron, NeuRAG) on startup.

    Tries to register with existing Gray-Matter.
    If Gray-Matter is not running, spawns one first,
    then runs the server's own MCP main loop.
    """
    autoregister(name, tool_names)

    # Start heartbeat in background
    import threading
    def _heartbeat_loop():
        while True:
            time.sleep(HEARTBEAT_INTERVAL)
            _send_heartbeat(name)
    t = threading.Thread(target=_heartbeat_loop, daemon=True)
    t.start()


def _record_self(role: str) -> None:
    """Iscrive questo processo al registro dei PID (INSTALLER-UX §7).

    Best-effort e mai bloccante: senza registro la suite funziona lo stesso,
    è `doctor` che smette di poter dire "questi due sono rimasti indietro".
    """
    try:
        from gray_matter import pids as _pids
        _pids.record_self(role)
    except Exception:  # noqa: BLE001
        pass


def run_daemon() -> None:
    """Registry/orchestrator only: IPC listener (:9876) + monitors, NO stdio MCP.
    This is how Gray-Matter runs when started as a background daemon (autoregister
    or `gray-matter start`) — there's no MCP client to attach stdio to, so main()'s
    stdio_server() would just exit on a detached process."""
    global _IS_DAEMON
    _IS_DAEMON = True          # owns the workers: must never delegate to itself
    _record_self("daemon")
    _reap_orphans()

    async def _run():
        # Stessa self-discovery di main(): era cablata SOLO nel ramo stdio, così
        # un daemon avviato con `gray-matter start` (o spawnato da autoregister)
        # restava con il registro vuoto — `status` diceva "Servers: 0" e ogni
        # gm-neuron/gm-neurag moriva con "worker gave no response". I due rami
        # devono partire dallo stesso stato: è lo stesso gateway.
        #
        # In BACKGROUND, non awaited prima del listener: il bootstrap interroga
        # i worker (spawn del subprocess + caricamento del modello) e può durare
        # decine di secondi. Awaitarlo qui teneva la porta IPC chiusa per tutto
        # quel tempo: `gray-matter start` diceva "started" e un `doctor` subito
        # dopo rispondeva "not running" con connessione rifiutata. main() fa lo
        # stesso: crea il task del listener PRIMA di aspettare il bootstrap.
        boot = asyncio.create_task(_bootstrap_subservers())
        boot.add_done_callback(lambda t: t.cancelled() or t.exception())
        await asyncio.gather(
            _ipc_listener(),
            _heartbeat_monitor(),
            _sleep_monitor(),
            _reap_dead_workers(),
            # The daemon owns the workers, so warming them is its job: without
            # this the first hook recall paid the model load (~2.6 s, over the
            # hook's 2.5 s timeout) and the session opener arrived empty.
            _prewarm_workers(),
        )
    asyncio.run(_run())


if __name__ == "__main__":
    import sys
    if "--daemon" in sys.argv:
        run_daemon()
    else:
        main()
